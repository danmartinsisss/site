const texto = [
  {
    type: "paragraph",
    children: [
      {
        text: "Sr(a) Usuário(a),",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "Nos termos da Portaria n° 55 de 09 de abril de 2021 da Corregedoria-Geral da Justiça do Estado de Mato Grosso, fica designado o dia 12 de abril de 2021 para a retomada do atendimento presencial ao público, mediante agendamento, pelas serventias extrajudiciais do estado.",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "Para agendamento acesse:",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "www.srisorriso.com.br",
        underline: true,
        bold: true,
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "Para solicitar certidões e protocolo de documentos eletrônicos:",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "app.anoregmt.org.br",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "Cartório do 1º Oficio da Comarca de Sorriso.",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "",
      },
    ],
  },
  {
    type: "bulleted-list",
    children: [
      {
        type: "list-item",
        children: [
          {
            text: "E-mail: srisorriso@terra.com.br",
          },
        ],
      },
    ],
  },
  {
    type: "bulleted-list",
    children: [
      {
        type: "list-item",
        children: [
          {
            text: "Telefones: (66) 3544-3030/3544-3535/3544-2997",
          },
        ],
      },
    ],
  },
  {
    type: "bulleted-list",
    children: [
      {
        type: "list-item",
        children: [
          {
            text: "Celular/WhatsApp: (66) 99655-5027",
          },
        ],
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "",
      },
    ],
  },
  {
    type: "paragraph",
    children: [
      {
        text: "Cartório do 1º Ofício da Comarca de Sorriso - MT",
      },
    ],
  },
];

export default texto;
