import React, { useEffect } from "react";
import Glide from "@glidejs/glide";
import { Box, Flex, Text } from "@chakra-ui/react";
import "@glidejs/glide/dist/css/glide.core.min.css";
import { ArrowBackIcon, ArrowForwardIcon } from "@chakra-ui/icons";

const Slider = ({onOpen}: any) => {
  const mainGlide = new Glide(".main__glide", {
    type: "carousel",
    focusAt: "center",
    perView: 1,
  });

  useEffect(() => {
    mainGlide.mount();
  }, [mainGlide]);

  return (
    <div className="main__glide">
      <Flex alignItems="center">
        <div data-glide-el="controls">
          <button
            className="slider__arrow slider__arrow--prev glide__arrow glide__arrow--prev"
            data-glide-dir="<"
          >
            <ArrowBackIcon w={8} h={8} />
          </button>
        </div>
        <div className="glide__track" data-glide-el="track">
          <ul className="glide__slides">
            <li className="glide__slide">
              <Box
                w="17em"
                h="250px"
                bgColor="#3a4856"
                textAlign="center"
                borderRadius={6}
                color="white"
                d="flex"
                onClick={() => onOpen()}
              >
                <Text m="auto" fontWeight="semibold">
                  Protocolo de Títulos e Documentos
                </Text>
              </Box>
            </li>
            <li className="glide__slide">
              <Box
                w="17em"
                h="250px"
                bgColor="#3a4856"
                textAlign="center"
                borderRadius={6}
                color="white"
                d="flex"
              >
                <Text m="auto" fontWeight="semibold">
                  Protocolo de Registro
                </Text>
              </Box>
            </li>
            <li className="glide__slide">
              <Box
                w="17em"
                h="250px"
                bgColor="#3a4856"
                textAlign="center"
                borderRadius={6}
                color="white"
                d="flex"
              >
                <Text m="auto" fontWeight="semibold">
                  Protocolo de Exame e Cálculo
                </Text>
              </Box>
            </li>
            <li className="glide__slide">
              <Box
                w="17em"
                h="250px"
                bgColor="#3a4856"
                textAlign="center"
                borderRadius={6}
                color="white"
                d="flex"
              >
                <Text m="auto" fontWeight="semibold">
                  Protocolo de Certidão
                </Text>
              </Box>
            </li>
            <li className="glide__slide">
              <Box
                w="17em"
                h="250px"
                bgColor="#3a4856"
                textAlign="center"
                borderRadius={6}
                color="white"
                d="flex"
              >
                <Text m="auto" fontWeight="semibold">
                  Validação de Documentos
                </Text>
              </Box>
            </li>
          </ul>
        </div>
        <div data-glide-el="controls">
          <button
            className="slider__arrow slider__arrow--next glide__arrow glide__arrow--next"
            data-glide-dir=">"
          >
            <ArrowForwardIcon w={8} h={8} />
          </button>
        </div>
      </Flex>
      <div data-glide-el="controls"></div>
    </div>
  );
};

export default Slider;
