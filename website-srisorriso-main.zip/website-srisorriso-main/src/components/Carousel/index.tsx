import React, { useEffect, useState } from 'react';
import {
  AspectRatio,
  Box,
  Flex,
  Heading,
  Image,
  Skeleton,
  useMediaQuery,
  Text,
} from '@chakra-ui/react';
import { motion } from 'framer-motion';

const Carousel = () => {
  const [image, setImage] = useState('topo1');
  const [index, setIndex] = useState(0);

  const variants = {
    hidden: { opacity: 0, x: 0, y: 20 },
    enter: { opacity: 1, x: 0, y: 0 },
    exit: { opacity: 0, x: -0, y: 20 },
  };

  const images = [
    'topo1',
    'topo2',
    'topo3',
    'topo4',
    'topo6',
    'topo7',
    'topo8',
    'topo9',
    'topo10',
    'topo11',
    'topo12',
    'topo13',
    'topo14',
  ];

  // useEffect(() => {
  // index < 13
  //   ? setTimeout(() => {
  //       setImage(images[index]);
  //       setIndex(index + 1);
  //     }, 6000)
  //   : setIndex(0);
  // }, [index]);

  return (
    <Box w="full" h="sm">
      <Box
        bgImage="url('background.jpeg')"
        bgPosition="center"
        bgRepeat="no-repeat"
        bgSize="cover"
        fallback={<Skeleton />}
        filter="blur(3px)"
        height="100%"
      />
      <Box
        backgroundColor="rgba(0,0,0, 0.4)"
        color="whiteAlpha.800"
        fontWeight="bold"
        position="absolute"
        top="87px"
        transform="translate(0%, 0%)"
        width="100%"
        height="sm"
        textAlign="left"
        paddingY={28}
        paddingX={48}
      >
        <motion.div
          initial="hidden"
          animate="enter"
          exit="exit"
          variants={variants}
          transition={{ duration: 1, type: 'easeInOut', delay: 0 }}
        >
          <Text fontSize="2xl">Bem Vindo ao</Text>
          <Heading size="2xl">1º Ofício de Sorriso - MT</Heading>
        </motion.div>
      </Box>
    </Box>
  );
};

export default Carousel;
