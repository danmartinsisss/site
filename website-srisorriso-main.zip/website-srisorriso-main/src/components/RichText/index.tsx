import { DeleteIcon } from '@chakra-ui/icons'
import {
  Box,
  Button,
  Divider,
  Flex,
  Heading,
  HStack,
  Icon,
  Image,
  Input,
  InputGroup,
  InputLeftAddon,
  ListItem,
  OrderedList,
  Switch,
  Text,
  UnorderedList
} from '@chakra-ui/react'
import { css } from '@emotion/react'
import axios from 'axios'
import isHotkey from 'is-hotkey'
import React, { useCallback, useEffect, useRef, useState } from 'react'
import {
  FaBold,
  FaFileImage,
  FaHeading,
  FaItalic,
  FaListOl,
  FaListUl,
  FaUnderline
} from 'react-icons/fa'
import {
  createEditor,
  Descendant,
  Editor,
  Element as SlateElement,
  Transforms
} from 'slate'
import {
  Editable,
  ReactEditor,
  Slate,
  useFocused,
  useSelected,
  useSlate,
  useSlateStatic,
  withReact
} from 'slate-react'

const HOTKEYS = {
  'mod+b': 'bold',
  'mod+i': 'italic',
  'mod+u': 'underline',
  'mod+`': 'code'
}

const LIST_TYPES = ['numbered-list', 'bulleted-list']

type NoticeProps = {
  data: {
    title: string
    text: string
    isActivated: string
  }
}

const RichText = ({ data }: NoticeProps) => {
  const [isLoading, setIsLoading] = useState(false)
  const [title, setTitle] = useState('')
  const [isActivated, setIsActivated] = useState(false)
  const [value, setValue] = useState<Descendant[]>(initialValues)
  const renderElement = useCallback(props => <Element {...props} />, [])
  const renderLeaf = useCallback(props => <Leaf {...props} />, [])
  const editorRef = useRef()
  //@ts-ignore
  if (!editorRef.current) editorRef.current = withReact(createEditor())
  const editor = editorRef.current

  useEffect(() => {
    if (data) {
      setValue(JSON.parse(data.text))
      setTitle(data.title)

      const active = data.isActivated === 'true' ? true : false
      setIsActivated(active)
    }
  }, [data])

  async function setNotice() {
    try {
      setIsLoading(true)
      const text = JSON.stringify(value)

      await axios
        .get('/api/firebase/setCurrentNotice', {
          params: { title: title, text: text, isActivated: isActivated }
        })
        .then(function (response) {
          console.log(response.statusText)
        })
        .catch(error => {
          console.log(error)
        })
        .finally(() => {
          setIsLoading(false)
        })
    } catch (e) {
      console.log(e)
    }
  }

  const handleActived = (value: boolean) => {
    setIsActivated(value)
  }

  return (
    <Slate
      //@ts-ignore
      ref={editorRef}
      editor={editor}
      value={value}
      initialValue={value}
      onChange={(value: any) => setValue(value)}
    >
      <Flex justifyContent='space-between' alignItems='center' bgColor='white' p={4} mt={4}>
        <HStack spacing={5}>
          <MarkButton format='bold' icon={<FaBold size='100%' />} />
          <MarkButton format='italic' icon={<FaItalic size='100%' />} />
          <MarkButton format='underline' icon={<FaUnderline size='100%' />} />
          {/* <MarkButton format="code" icon={<FaCode size="100%" />} /> */}
          <BlockButton format='heading-one' icon={<FaHeading size='100%' />} />
          <BlockButton format='heading-two' icon={<FaHeading size='100%' />} />
          {/* <BlockButton format="block-quote" icon={<GrBlockQuote size="100%" />} /> */}
          <BlockButton format='numbered-list' icon={<FaListOl size='100%' />} />
          <BlockButton format='bulleted-list' icon={<FaListUl size='100%' />} />
          <InsertImageButton />
        </HStack>
        <Switch
          isChecked={isActivated}
          onChange={event => handleActived(event?.target.checked)}
        />
      </Flex>
      <Divider borderTop='1px solid #bbb' />
      <Box bgColor='white' p={2}>
        <InputGroup variant='filled' colorScheme='blue'>
          <InputLeftAddon>Título:</InputLeftAddon>
          <Input
            type='text'
            placeholder='Título'
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
        </InputGroup>
      </Box>
      <Box bgColor='white' p={6} mb={4} border='1px' borderColor='gray.200'>
        <Editable
          renderElement={renderElement}
          renderLeaf={renderLeaf}
          placeholder='Insira seu texto...'
          spellCheck
          autoFocus
          onKeyDown={event => {
            for (const hotkey in HOTKEYS) {
              if (isHotkey(hotkey, event as any)) {
                event.preventDefault()
                //@ts-ignore
                const mark = HOTKEYS[hotkey]
                toggleMark(editor, mark)
              }
            }
          }}
        />
      </Box>
      <Flex justifyContent='flex-end'>
        <Button
          isLoading={isLoading}
          loadingText='Salvando'
          colorScheme='blue'
          onClick={setNotice}
        >
          Salvar
        </Button>
      </Flex>
    </Slate>
  )
}

const toggleBlock = (editor: any, format: any) => {
  const isActive = isBlockActive(editor, format)
  const isList = LIST_TYPES.includes(format)

  Transforms.unwrapNodes(editor, {
    match: n =>
      LIST_TYPES.includes(
        //@ts-ignore
        !Editor.isEditor(n) && SlateElement.isElement(n) && n.type
      ),
    split: true
  })
  const newProperties: Partial<SlateElement> = {
    //@ts-ignore
    type: isActive ? 'paragraph' : isList ? 'list-item' : format
  }
  Transforms.setNodes(editor, newProperties)

  if (!isActive && isList) {
    const block = { type: format, children: [] }
    Transforms.wrapNodes(editor, block)
  }
}

const toggleMark = (editor: any, format: any) => {
  const isActive = isMarkActive(editor, format)

  if (isActive) {
    Editor.removeMark(editor, format)
  } else {
    Editor.addMark(editor, format, true)
  }
}

const isBlockActive = (editor: any, format: any) => {
  //@ts-ignore
  const [match] = Editor.nodes(editor, {
    match: n =>
      //@ts-ignore
      !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === format
  })

  return !!match
}

const isMarkActive = (editor: any, format: any) => {
  const marks = Editor.marks(editor)
  //@ts-ignore
  return marks ? marks[format] === true : false
}

const ImageElement = ({ attributes, children, element }) => {
  const selected = useSelected()
  const focused = useFocused()
  return (
    <div {...attributes}>
      {children}

      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={element.url}
        alt='image'
        //@ts-ignore
        className={css`
          display: block;
          max-width: 100%;
          max-height: 20em;
          box-shadow: ${selected && focused ? '0 0 0 2px blue;' : 'none'};
        `}
      />
    </div>
  )
}

type EmptyText = {
  text: string
}

type ImageElement = {
  type: 'image'
  url: string
  children: EmptyText[]
}

const insertImage = (editor, url) => {
  const image: ImageElement = {
    type: 'image',
    url,
    children: [
      {
        text: ''
      }
    ]
  }
  Transforms.insertNodes(editor, image)
}

const Element = props => {
  const { attributes, children, element } = props

  switch (element.type) {
    case 'image':
      return <ImageTest {...props} />
    case 'block-quote':
      return (
        <Text as='cite' {...attributes}>
          {children}
        </Text>
      )
    case 'bulleted-list':
      return (
        <UnorderedList>
          <ListItem {...attributes}>{children}</ListItem>
        </UnorderedList>
      )
    case 'heading-one':
      return (
        <Heading size='lg' {...attributes}>
          {children}
        </Heading>
      )
    case 'heading-two':
      return (
        <Heading size='md' {...attributes}>
          {children}
        </Heading>
      )
    case 'list-item':
      return <li {...attributes}>{children}</li>
    case 'numbered-list':
      return (
        <OrderedList>
          <ListItem {...attributes}>{children}</ListItem>
        </OrderedList>
      )
    default:
      return <Text {...attributes}>{children}</Text>
  }
}

const Leaf = ({ attributes, children, leaf }: any) => {
  if (leaf.bold) {
    children = <Text as='b'>{children}</Text>
  }

  if (leaf.code) {
    children = <Text as='kbd'>{children}</Text>
  }

  if (leaf.italic) {
    children = <Text as='i'>{children}</Text>
  }

  if (leaf.underline) {
    children = <Text as='u'>{children}</Text>
  }

  return <span {...attributes}>{children}</span>
}

const BlockButton = ({ format, icon }: any) => {
  const editor = useSlate()
  return (
    <Button
      // active={isBlockActive(editor, format)}
      onMouseDown={(event: any) => {
        event.preventDefault()
        toggleBlock(editor, format)
      }}
    >
      <Icon>{icon}</Icon>
    </Button>
  )
}

const MarkButton = ({ format, icon }: any) => {
  const editor = useSlate()
  return (
    <Button
      // active={isMarkActive(editor, format)}
      onMouseDown={event => {
        event.preventDefault()
        toggleMark(editor, format)
      }}
    >
      <Icon>{icon}</Icon>
    </Button>
  )
}

const ImageTest = ({ attributes, children, element }) => {
  const editor = useSlateStatic()
  //@ts-ignore
  const path = ReactEditor.findPath(editor, element)

  const selected = useSelected()
  const focused = useFocused()
  return (
    <div {...attributes}>
      {children}
      <div
        contentEditable={false}
        //@ts-ignore
        className={css`
          position: relative;
        `}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <Image
          src={element.url}
          alt='image'
          css={{
            display: 'block',
            boxShadow: selected && focused ? '0 0 0 3px #B4D5FF' : 'none'
          }}
        />
        <Button
          active
          onClick={() => Transforms.removeNodes(editor, { at: path })}
          css={{
            display: selected && focused ? 'inline' : 'none',
            position: 'absolute',
            top: '1.5rem',
            left: '0.5rem',
            backgroundColor: 'gray.200'
          }}
        >
          <DeleteIcon />
        </Button>
      </div>
    </div>
  )
}

const InsertImageButton = () => {
  const editor = useSlateStatic()
  return (
    <Button
      onMouseDown={event => {
        event.preventDefault()
        const url = window.prompt('Enter the URL of the image:')
        // if (url && !isImageUrl(url)) {
        //   alert('URL is not an image')
        //   return
        // }
        insertImage(editor, url)
      }}
    >
      <FaFileImage />
    </Button>
  )
}

// const isImageUrl = url => {
//   if (!url) return false
//   if (!isUrl(url)) return false
//   const ext = new URL(url).pathname.split('.').pop()
//   return imageExtensions.includes(ext)
// }

const initialValues = [
  {
    type: 'paragraph',
    children: [
      {
        text: 'Insira o texto do aviso aqui...'
      }
    ]
  }
]

export default RichText
