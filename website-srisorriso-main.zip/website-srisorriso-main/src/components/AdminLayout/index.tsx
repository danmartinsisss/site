import React, { ReactNode } from "react";
import NextLink from "next/link";
import Head from "next/head";
import {
  Flex,
  Button,
  Heading,
  Stack,
  Text,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
} from "@chakra-ui/react";
import { ChevronDownIcon } from "@chakra-ui/icons";

type AdminLayoutProps = {
  children: ReactNode;
};

const AdminLayout = ({ children }: AdminLayoutProps) => {
  const handleLogout = () => {
    localStorage.clear();
    window.location.href = "/admin/login";
  };

  return (
    <>
      <Head>
        <title>1º Ofício de Sorriso - MT</title>
      </Head>
      <Flex
        flexDirection="row"
        justifyContent="space-between"
        alignItems="center"
        width="100%"
        as="section"
        bg="blue.600"
        px={[2, 6, 6]}
        py={3}
        mx="auto"
      >
        {/* <Heading color="white" size="lg">
          Área Restrita
        </Heading> */}
        <Stack direction="row" spacing={5}>
          <Menu>
            <MenuButton
              as={Button}
              rightIcon={<ChevronDownIcon />}
              variant="unstyled"
              color="white"
            >
              Avisos
            </MenuButton>
            <MenuList>
              <NextLink href="/admin/avisos/publicar">
                <MenuItem>Publicar aviso</MenuItem>
              </NextLink>
              <NextLink href="/admin/avisos/novo">
                <MenuItem>Novo modelo</MenuItem>
              </NextLink>
            </MenuList>
          </Menu>
          <NextLink href="/admin/galeria">
            <Button variant="unstyled" color="white">
              <Text>Galeria</Text>
            </Button>
          </NextLink>
        </Stack>
        <Button colorScheme="blue" onClick={handleLogout}>
          Sair
        </Button>
      </Flex>
      <Flex as="main" justifyContent="column" mt={6}>
        {children}
      </Flex>
    </>
  );
};

export default AdminLayout;
