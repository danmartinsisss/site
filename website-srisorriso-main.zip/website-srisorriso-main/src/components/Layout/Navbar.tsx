import { HamburgerIcon } from '@chakra-ui/icons'
import {
  Box,
  Button,
  Flex,
  Image,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Stack
} from '@chakra-ui/react'
import NextLink from 'next/link'
import React from 'react'

export const Navbar = () => {
  return (
    <Flex width='100%' flexDir='column' bgColor='gray.300'>
      <Flex
        h={102}
        justifyContent='center'
        bgColor='#203864'
        display={['none', 'none', 'flex', 'flex']}
      >
        <Box position='absolute' left={38} top={2}>
          <Image src='/logo.png' alt='Logo 1º Ofício de Sorriso - MT' maxW='30%' />
        </Box>
        <Stack direction='row' spacing={10} py={4}>
          <NextLink href='/home'>
            <Button color='white' variant='link'>
              Home
            </Button>
          </NextLink>
          <NextLink href='/links'>
            <Button color='white' variant='link'>
              Links úteis
            </Button>
          </NextLink>
          <NextLink href='/institucional'>
            <Button color='white' variant='link'>
              Institucional
            </Button>
          </NextLink>
          <NextLink href='/contato'>
            <Button color='white' variant='link'>
              Contato
            </Button>
          </NextLink>
        </Stack>
      </Flex>
      <Flex
        justifyContent='left'
        bgColor='rgba(75,120,155,0.7)'
        display={['flex', 'flex', 'none', 'none']}
      >
        <Menu>
          <MenuButton as={Button} variant='ghost' colorScheme='blue' size='lg'>
            <HamburgerIcon color='white' />
          </MenuButton>
          <MenuList>
            <NextLink href='/home'>
              <MenuItem>Home</MenuItem>
            </NextLink>
            <NextLink href='/links'>
              <MenuItem>Links úteis</MenuItem>
            </NextLink>
            <NextLink href='/institucional'>
              <MenuItem>Institucional</MenuItem>
            </NextLink>
            <NextLink href='/contato'>
              <MenuItem>Contato</MenuItem>
            </NextLink>
          </MenuList>
        </Menu>
      </Flex>
    </Flex>
  )
}
