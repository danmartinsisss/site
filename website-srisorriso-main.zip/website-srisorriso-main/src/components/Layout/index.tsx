import React, { ReactNode } from "react";
import Head from "next/head";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { Flex } from "@chakra-ui/react";

type LayoutProps = {
  children: ReactNode;
};

export const Layout = ({ children }: LayoutProps) => {
  return (
    <>
      <Head>
        <title>1º Ofício de Sorriso - MT</title>
      </Head>
      <Navbar />
      <Flex as="main" minH="70vh" direction="column" bgColor="whitesmoke">
        {children}
      </Flex>
      <Footer />
    </>
  );
};
