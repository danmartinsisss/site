import { Text, TextProps } from '@chakra-ui/layout'
import * as React from 'react'

export const Copyright = (props: TextProps) => (
  <Text fontSize='sm' {...props} color='whiteAlpha.800'>
    &copy; {new Date().getFullYear()} Cartório do 1º Ofício de Sorriso - MT. Todos os
    direitos reservados.
  </Text>
)
