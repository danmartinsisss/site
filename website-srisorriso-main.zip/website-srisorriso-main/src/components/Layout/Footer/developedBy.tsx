import { ButtonGroup, ButtonGroupProps, Text } from '@chakra-ui/react'
import * as React from 'react'

export const DevelopedBy = (props: ButtonGroupProps) => (
  <ButtonGroup variant='ghost' color='#3a4856' {...props}>
    <Text as='a' fontSize={['sm', 'md']} target='_blank'>
      Depto TI SRI Sorriso.
    </Text>
  </ButtonGroup>
)
