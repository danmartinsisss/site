import {
  Box,
  HStack,
  Link,
  SimpleGrid,
  SimpleGridProps,
  Stack,
  Text
} from '@chakra-ui/react'
import NextLink from 'next/link'
import * as React from 'react'
import { FaEnvelope, FaMapMarkerAlt, FaPhone, FaWhatsappSquare } from 'react-icons/fa'
import { FooterHeading } from './footerHeading'

export const LinkGrid = (props: SimpleGridProps) => (
  <SimpleGrid columns={[1, 2]} {...props}>
    <Box minW='130px' color='whiteAlpha.800'>
      <FooterHeading mb='4' color='whiteAlpha.700'>
        Contato
      </FooterHeading>
      <HStack mb={3}>
        <FaPhone />
        <Text as='a' href='tel:+556635443030' mb={3}>
          +55 66 3544-3030
        </Text>
      </HStack>
      <HStack mb={3}>
        <FaWhatsappSquare />
        <Text as='a' href='https:\/\/api.whatsapp.com\/send?phone=5566999272063&text=Olá!' mb={3}>
          Whatsapp +55 66 99927-2063
        </Text>
      </HStack>
      <HStack mb={3}>
        <FaEnvelope />
        <Text as='a' href='mailto:srisorriso@terra.com.br' mb={3}>
          srisorriso@terra.com.br
        </Text>
      </HStack>
      <HStack mb={3}>
        <FaMapMarkerAlt />
        <Text mb={2} textAlign='justify'>
          Av. Blumenau, 2727 - Centro, Sorriso - MT <br />
          CEP: 78.890-168
        </Text>
      </HStack>
    </Box>
    <Box minW='130px' color='whiteAlpha.800'>
      <FooterHeading mb='4' color='whiteAlpha.700'>
        Serviços
      </FooterHeading>
      <Stack>
        <Link
          _hover={{ textDecoration: 'none' }}
          href='https://registradores.onr.org.br/'
          isExternal
        >
          Serviços online
        </Link>
        <NextLink href='#consultas'>Consultas</NextLink>
        <NextLink href='/tabelas'>Tabela de emolumentos</NextLink>
        <NextLink href='/requerimentos'>Requerimentos</NextLink>
      </Stack>
    </Box>
  </SimpleGrid>
)
