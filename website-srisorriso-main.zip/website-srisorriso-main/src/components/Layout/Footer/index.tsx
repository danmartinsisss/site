import { Box, Center, Image, Stack, StackDivider } from '@chakra-ui/react'
import * as React from 'react'
import { Copyright } from './copyright'
import { DevelopedBy } from './developedBy'
import { LinkGrid } from './linkGrid'

export const Footer = () => (
  <Box
    as='footer'
    role='contentinfo'
    position='relative'
    maxW='full'
    mx='auto'
    py='6'
    bgColor='#203864'
  >
    <Center>
      <Stack w='container.xl' px={6} spacing='4' divider={<StackDivider />}>
        <Stack direction={{ base: 'column', lg: 'row' }} spacing={{ base: '10', lg: '18' }}>
          <Box minW='130px'>
            <Image src='/logo.png' alt='Logo 1º Ofício de Sorriso - MT' maxW='55%' />
          </Box>
          <Stack
            direction={{ base: 'column', md: 'row' }}
            spacing={{ base: '10', md: '20' }}
          >
            <LinkGrid spacing={{ base: '10', md: '20', lg: '28' }} flex='1' />
          </Stack>
        </Stack>
        <Stack
          direction={{ base: 'column', md: 'row' }}
          justifyContent='space-between'
          alignItems='center'
        >
          <Copyright />
          <DevelopedBy />
        </Stack>
      </Stack>
    </Center>
  </Box>
)
