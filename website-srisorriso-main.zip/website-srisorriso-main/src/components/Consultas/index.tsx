import {
  Box,
  Button,
  FormControl,
  FormHelperText,
  FormLabel,
  Input,
  InputGroup,
  NumberInput,
  NumberInputField,
  Stack,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  useDisclosure,
  useMediaQuery
} from '@chakra-ui/react'
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import ModalCertidaoRegistro from '../Modal/ModalCertidaoRegistro'
import ModalCertidaoTitulosDocumentos from '../Modal/ModalCertidaoTitulosDocumentos'
import ModalRegistro from '../Modal/ModalRegistro'
import ModalTitulosDocumentos from '../Modal/ModalTitulosDocumentos'

const Consultas = () => {
  const [isLargerThan425] = useMediaQuery('(min-width: 425px)')
  const [isLoading, setIsLoading] = useState(false)
  const {
    isOpen: isOpenRegistro,
    onOpen: onOpenRegistro,
    onClose: onCloseRegistro
  } = useDisclosure()
  const {
    isOpen: isOpenCertidaoRegistro,
    onOpen: onOpenCertidaoRegistro,
    onClose: onCloseCertidaoRegistro
  } = useDisclosure()
  const {
    isOpen: isOpenTitulosDocumentos,
    onOpen: onOpenTitulosDocumentos,
    onClose: onCloseTitulosDocumentos
  } = useDisclosure()
  const {
    isOpen: isOpenCertidaoTitulosDocumentos,
    onOpen: onOpenCertidaoTitulosDocumentos,
    onClose: onCloseCertidaoTitulosDocumentos
  } = useDisclosure()
  const [error, setError] = useState(null)
  const [isDisable, setIsDisable] = useState(false)
  const [values, setValues] = useState({
    protocoloRegistro: '',
    protocoloCertidaoRegistro: '',
    protocoloTitulosDocumentos: '',
    protocoloCertidaoTitulosDocumentos: ''
  })

  useEffect(() => {
    !isOpenRegistro && localStorage.clear()
  }, [isOpenRegistro])
  useEffect(() => {
    !isOpenTitulosDocumentos && localStorage.clear()
  }, [isOpenTitulosDocumentos])
  useEffect(() => {
    !isOpenCertidaoRegistro && localStorage.clear()
  }, [isOpenCertidaoRegistro])
  useEffect(() => {
    !isOpenCertidaoTitulosDocumentos && localStorage.clear()
  }, [isOpenCertidaoTitulosDocumentos])

const getDataRegistro = () => {
  try {
    setError(null)
    setIsLoading(true)
    setIsDisable(true)

    axios
      .get('/api/escriba/protocoloRegistro', {
        params: {
          protocolo: values?.protocoloRegistro
        }
      })
      .then(async response => {
        console.log('Dados recebidos da API:', response.data) // Adiciona um log para verificar os dados

        if (response.data) {
          // Verifica se os dados têm a estrutura correta antes de armazenar
          localStorage.setItem('registro', JSON.stringify(response.data))

          // Abre o modal de registro
          onOpenRegistro()
        } else {
          console.error('Estrutura dos dados inesperada:', response.data)
        }
      })
      .catch(error => {
        setError(error)
        console.error('Erro ao consultar a API:', error)
      })
      .finally(() => {
        setIsLoading(false)
        setIsDisable(false)
      })
  } catch (error) {
    console.error('Erro ao tentar consultar o protocolo:', error)
  }
}

  const getDataCertidaoRegistro = () => {
    try {
      setError(null)
      setIsLoading(true)
      setIsDisable(true)

      axios
        .get('/api/escriba/certidaoRegistro', {
          params: {
            protocolo: values?.protocoloCertidaoRegistro
          }
        })
        .then(async response => {
          localStorage.setItem('certidaoRegistro', JSON.stringify(response.data))
          onOpenCertidaoRegistro()
        })
        .catch(error => {
          setError(error)
        })
        .finally(() => {
          setIsLoading(false)
          setIsDisable(false)
        })
    } catch (error) {
      console.error(error)
    }
  }

  const getDataTitulosDocumentos = () => {
    try {
      setError(null)
      setIsLoading(true)
      setIsDisable(true)

      axios
        .get('/api/escriba/protocoloTitulosDocumentos', {
          params: {
            protocolo: values?.protocoloTitulosDocumentos
          }
        })
        .then(async response => {
          localStorage.setItem('titulosDocumentos', JSON.stringify(response.data))
          onOpenTitulosDocumentos()
        })
        .catch(error => {
          setError(error)
        })
        .finally(() => {
          setIsLoading(false)
          setIsDisable(false)
        })
    } catch (error) {
      console.error(error)
    }
  }

  const getDataCertidaoTitulosDocumentos = () => {
    try {
      setError(null)
      setIsLoading(true)
      setIsDisable(true)

      axios
        .get('/api/escriba/certidaoTitulosDocumentos', {
          params: {
            protocolo: values?.protocoloCertidaoTitulosDocumentos
          }
        })
        .then(async response => {
          localStorage.setItem('certidaoTitulosDocumentos', JSON.stringify(response.data))
          onOpenCertidaoTitulosDocumentos()
        })
        .catch(error => {
          setError(error)
        })
        .finally(() => {
          setIsLoading(false)
          setIsDisable(false)
        })
    } catch (error) {
      console.error(error)
    }
  }

  const handleChange = prop => event => {
    setValues({ ...values, [prop]: event.target.value })
  }

  return (
    <>
      <ModalRegistro isOpen={isOpenRegistro} onClose={onCloseRegistro} />
      <ModalCertidaoRegistro
        isOpen={isOpenCertidaoRegistro}
        onClose={onCloseCertidaoRegistro}
      />
      <ModalTitulosDocumentos
        isOpen={isOpenTitulosDocumentos}
        onClose={onCloseTitulosDocumentos}
      />
      <ModalCertidaoTitulosDocumentos
        isOpen={isOpenCertidaoTitulosDocumentos}
        onClose={onCloseCertidaoTitulosDocumentos}
      />
      <Tabs orientation={isLargerThan425 ? 'horizontal' : 'vertical'}>
        <TabList>
          <Tab _selected={{ color: 'white', bg: '#3862b0' }}>Registro de Imóveis</Tab>
          <Tab _selected={{ color: 'white', bg: '#3862b0' }}>
            Certidão de Registro de Imóveis
          </Tab>
          <Tab _selected={{ color: 'white', bg: '#3862b0' }}>
            Registro de Títulos e Documentos
          </Tab>
          <Tab _selected={{ color: 'white', bg: '#3862b0' }}>
            Certidão de Títulos e Documentos
          </Tab>
        </TabList>
        <TabPanels>
          <TabPanel>
            <Box>
              <Stack p={4} maxW={['sm', 'lg']} m='auto' spacing={6}>
                <FormControl>
                  <FormLabel>Protocolo Registro: </FormLabel>
                  <NumberInput size='lg'>
                    <NumberInputField
                      disabled={isDisable}
                      placeholder='Protocolo'
                      value={values.protocoloRegistro}
                      onChange={handleChange('protocoloRegistro')}
                    />
                  </NumberInput>
                  <FormHelperText color='white' bgColor='red'>
                    {error?.message}
                  </FormHelperText>
                </FormControl>
                <Button
                  backgroundColor='#3862b0'
                  _hover={{ filter: 'brightness(0.9)' }}
                  isLoading={isLoading}
                  onClick={getDataRegistro}
                >
                  Consultar
                </Button>
              </Stack>
            </Box>
          </TabPanel>
          <TabPanel>
            <Box>
              <Stack p={4} maxW={['sm', 'lg']} m='auto' spacing={6}>
                <FormControl>
                  <FormLabel>Protocolo Certidão de Registro: </FormLabel>
                  <NumberInput size='lg'>
                    <NumberInputField
                      disabled={isDisable}
                      placeholder='Protocolo'
                      value={values.protocoloCertidaoRegistro}
                      onChange={handleChange('protocoloCertidaoRegistro')}
                    />
                  </NumberInput>
                  <FormHelperText color='white' bgColor='red'>
                    {error?.message}
                  </FormHelperText>
                </FormControl>
                <Button
                  colorScheme='blue'
                  isLoading={isLoading}
                  onClick={getDataCertidaoRegistro}
                >
                  Consultar
                </Button>
              </Stack>
            </Box>
          </TabPanel>
          <TabPanel>
            <Box>
              <Stack p={4} maxW={['sm', 'lg']} m='auto' spacing={6}>
                <FormControl>
                  <FormLabel>Protocolo Títulos e Documentos: </FormLabel>
                  <InputGroup size='lg'>
                    <Input
                      disabled={isDisable}
                      placeholder='Protocolo'
                      value={values.protocoloTitulosDocumentos}
                      onChange={handleChange('protocoloTitulosDocumentos')}
                    />
                  </InputGroup>
                  <FormHelperText color='white' bgColor='red'>
                    {error?.message}
                  </FormHelperText>
                </FormControl>
                <Button
                  colorScheme='blue'
                  isLoading={isLoading}
                  onClick={getDataTitulosDocumentos}
                >
                  Consultar
                </Button>
              </Stack>
            </Box>
          </TabPanel>
          <TabPanel>
            <Box>
              <Stack p={4} maxW={['sm', 'lg']} m='auto' spacing={6}>
                <FormControl>
                  <FormLabel>Protocolo Certidão de Títulos e Documentos:</FormLabel>
                  <NumberInput size='lg'>
                    <NumberInputField
                      disabled={isDisable}
                      placeholder='Protocolo'
                      value={values.protocoloCertidaoTitulosDocumentos}
                      onChange={handleChange('protocoloCertidaoTitulosDocumentos')}
                    />
                  </NumberInput>
                  <FormHelperText color='white' bgColor='red'>
                    {error?.message}
                  </FormHelperText>
                </FormControl>
                <Button
                  colorScheme='blue'
                  isLoading={isLoading}
                  onClick={getDataCertidaoTitulosDocumentos}
                >
                  Consultar
                </Button>
              </Stack>
            </Box>
          </TabPanel>
        </TabPanels>
      </Tabs>
    </>
  )
}

export default Consultas
