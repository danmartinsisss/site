import { Container, SimpleGrid } from '@chakra-ui/react'
import React from 'react'
import {
  FaBookOpen,
  FaFileSignature,
  FaListAlt,
  FaPenSquare,
  FaQuestion
} from 'react-icons/fa'
import { Card } from './card'

type CardProps = {
  title: string
  icon: React.ReactElement
  link?: string
  isExternal?: boolean
}

const cards: CardProps[] = [
  {
    title: 'Validação de Documentos',
    icon: <FaFileSignature size={70} fill='#3a4856' />,
    link: 'https://registradores.onr.org.br/validacao.aspx',
    isExternal: true
  },
  {
    title: 'Requerimentos',
    icon: <FaPenSquare size={70} fill='#3a4856' />,
    link: '/requerimentos',
    isExternal: false
  },
  {
    title: 'Cartilha Extrajudicial',
    icon: <FaBookOpen size={70} fill='#3a4856' />,
    link: '/files/Cartilha_Extrajudicial.pdf',
    isExternal: true
  },
  {
    title: 'Tabela de Emolumentos',
    icon: <FaListAlt size={70} fill='#3a4856' />,
    link: '/tabelas',
    isExternal: false
  },
  {
    title: 'Perguntas e Respostas',
    icon: <FaQuestion size={70} fill='#3a4856' />
  }
]

export default function ServiceCards({ onOpenDuvidas }) {
  return (
    <Container
      maxW={{ base: 'container.sm', md: 'container.xl' }}
      position='relative'
      mt='5rem'
      mb='5rem'
      px={{ base: 8, md: 8, lg: 8, xl: 4 }}
    >
      <SimpleGrid columns={{ base: 1, md: 2, lg: 5, xl: 5 }} spacing='2' color='#3a4856'>
        {cards.map((card: CardProps) => {
          if (card.title === 'Perguntas e Respostas') {
            return (
              <Card
                key={card.title}
                title={card.title}
                icon={card.icon}
                onClick={onOpenDuvidas}
              />
            )
          } else {
            return (
              <Card
                key={card.title}
                title={card.title}
                icon={card.icon}
                link={card.link}
                isExternal={card.isExternal}
              />
            )
          }
        })}
      </SimpleGrid>
    </Container>
  )
}
