import { Box, Button, Link, Text } from '@chakra-ui/react'

type CardProps = {
  title: string
  icon: React.ReactElement
  link?: string
  isExternal?: boolean
  onClick?: () => void
}

export const Card = ({ title, icon, link, isExternal, onClick }: CardProps) => {
  return (
    <Box
      minH={300}
      maxW={500}
      bg='white'
      borderWidth={1}
      borderColor='gray.200'
      borderRadius={12}
      _hover={{
        boxShadow: '0px 8px 30px 0px rgba(0,0,0,0.1)',
        transition: 'box-shadow 0.3s ease-in-out'
      }}
    >
      <Box height={['20%', '30%']} px={2} py={2}>
        <Text fontSize='0.95rem' fontWeight='semibold' textTransform='uppercase'>
          {title}
        </Text>
      </Box>
      <Box height='50%' display='flex' justifyContent='center' alignItems='center'>
        {icon}
      </Box>
      <Box
        display='flex'
        alignItems='center'
        justifyContent='center'
        height={['30%', '20%']}
      >
        <Button
          as={Link}
          href={link}
          isExternal={isExternal}
          _hover={{ textDecoration: 'none' }}
          colorScheme='blue'
          onClick={onClick}
        >
          Acessar
        </Button>
      </Box>
    </Box>
  )
}
