import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalHeader,
  ModalOverlay,
  Stack,
  UseDisclosureProps
} from '@chakra-ui/react'
import NextLink from 'next/link'
import React from 'react'

const ModalDuvidas = ({ isOpen, onClose }: UseDisclosureProps) => {
  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Selecione a atribuição</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Stack padding={6}>
              <NextLink href='/duvidas/ri'>
                <Button colorScheme='blue' size='md'>
                  REGISTRO DE IMÓVEIS
                </Button>
              </NextLink>
              <NextLink href='/duvidas/rtd'>
                <Button colorScheme='blue' size='md'>
                  TÍTULOS E DOCUMENTOS
                </Button>
              </NextLink>
            </Stack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  )
}

export default ModalDuvidas
