import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  SimpleGrid,
  Stack,
  Text,
  UseDisclosureProps,
} from "@chakra-ui/react";
import { jsPDF } from "jspdf";

type servicosRelacionadosProps = {
  chave: string;
  livro: string;
  descricao: string;
};

type etapasProps = {
  id: Number;
  descricao: String;
  ordem: Number;
};

type TitulosDocumentosProps = {
  numProtocolo: String;
  numRegistro: String;
  natureza: String;
  apresentante: String;
  etapas: Array<etapasProps>;
  etapaAtual: Number;
  exigencia: {
    dataExigencia: string;
    prazoEntregaExigencia: string;
    texto: string;
  };
};

const ModalTitulosDocumentos = ({ isOpen, onClose }: UseDisclosureProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [etapa, setEtapa] = useState("");
  const [dataTitulosDocumentos, setDataTitulosDocumentos] =
    useState<TitulosDocumentosProps>({
      numProtocolo: "",
      numRegistro: "",
      natureza: "",
      apresentante: "",
      etapas: [],
      etapaAtual: null,
    });

  useEffect(() => {
    const dataTitulosDocumentos = JSON.parse(
      localStorage.getItem("titulosDocumentos")
    );
    setDataTitulosDocumentos(dataTitulosDocumentos);
  }, [isOpen]);

  useEffect(() => {
    // if(dataTitulosDocumentos?.exigencia?.texto) {
    //   setEtapa('EM EXIGÊNCIA');
    // } else {
      const etapa = dataTitulosDocumentos?.etapas.find(
        (element) => element.id === dataTitulosDocumentos.etapaAtual
      );
      setEtapa(etapa?.descricao.toString());
    // }
  }, [dataTitulosDocumentos]);

  const generatePdf = async () => {
    const text = document.getElementById("text");
    try {
      setIsLoading(true);
      text.hidden = false;

      const doc = new jsPDF();

      doc.setFontSize(11);
      doc.text("CARTÓRIO 1º OFÍCIO DA COMARCA DE SORRISO", 60, 10);
      doc.text(
        "Registro de Imóveis e de Títulos e Documentos da Comarca de Sorriso",
        45,
        20
      );
      doc.text("Av. Blumenau, 3284 - Centro, Sorriso - MT", 70, 25);
      doc.setFont("", "", "bold");
      doc.text("NOTA DE EXIGÊNCIA", 85, 35);

      let split = doc.splitTextToSize(text.innerText, 200);

      doc.setFont("", "", "normal");
      doc.setFontSize(10);
      doc.text(split, 5, 50);
      // doc.save("Termo de Quitação de Dívida");
      doc.output("dataurlnewwindow");
    } catch (e) {
      console.log(e);
    }
    setIsLoading(false);
    text.hidden = true;
  };

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} size="3xl">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Consulta Títulos e Documentos</ModalHeader>
          <ModalCloseButton />

          <ModalBody>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Protocolo
                </Text>
                <span>{dataTitulosDocumentos?.numProtocolo}</span>
              </Stack>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Status
                </Text>
                <span>{etapa}</span>
              </Stack>
            </SimpleGrid>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Registro
                </Text>
                <span>{dataTitulosDocumentos?.numRegistro}</span>
              </Stack>
              <Stack gridColumnStart={2} gridColumnEnd={4}>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Natureza
                </Text>
                <span>{dataTitulosDocumentos?.natureza}</span>
              </Stack>
            </SimpleGrid>
            <Stack mb={8}>
              <Text
                fontSize="sm"
                fontWeight="bold"
                _after={{
                  content: '""',
                  display: "block",
                  position: "absolute",
                  width: "1.75rem",
                  height: "0.1rem",
                  background: "darkgrey",
                }}
                mb={2}
              >
                Apresentante
              </Text>
              <span>{dataTitulosDocumentos?.apresentante}</span>
            </Stack>
            {dataTitulosDocumentos?.exigencia && (
              <div
                id="text"
                hidden
                dangerouslySetInnerHTML={{
                  __html: dataTitulosDocumentos?.exigencia?.texto.toString(),
                }}
              ></div>
            )}
          </ModalBody>

          <ModalFooter>
            {dataTitulosDocumentos?.exigencia && (
              <Button
                isLoading={isLoading}
                colorScheme="blue"
                mr={3}
                onClick={generatePdf}
              >
                Exigência
              </Button>
            )}
            <Button variant="ghost" onClick={onClose}>
              Fechar
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};

export default ModalTitulosDocumentos;
