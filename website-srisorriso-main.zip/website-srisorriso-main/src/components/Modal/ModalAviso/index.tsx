import {
  Heading,
  Image,
  ListItem,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalHeader,
  ModalOverlay,
  OrderedList,
  Text,
  UnorderedList
} from '@chakra-ui/react'
import { css } from '@emotion/react'
import axios from 'axios'
import React, { useCallback, useEffect, useRef, useState } from 'react'
import { createEditor, Descendant } from 'slate'
import { Editable, Slate, withReact } from 'slate-react'

const ModalAviso = () => {
  const [value, setValue] = useState<Descendant[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const renderElement = useCallback(props => <Element {...props} />, [])
  const renderLeaf = useCallback(props => <Leaf {...props} />, [])
  const editorRef = useRef()
  //@ts-ignore
  if (!editorRef.current) editorRef.current = withReact(createEditor())
  const editor = editorRef.current

  useEffect(() => {
    async function getNotice() {
      await axios
        .get('/api/firebase/getCurrentNotice')
        .then(response => {
          setValue(JSON.parse(response.data.text))
          response.data.isActivated === 'true' ? setIsOpen(true) : setIsOpen(false)
        })
        .catch(error => console.log(error))
    }

    getNotice()
  }, [])

  return (
    <Modal
      closeOnOverlayClick={false}
      isOpen={isOpen}
      onClose={() => setIsOpen(false)}
      size='2xl'
    >
      <ModalOverlay />
      <ModalContent position={['relative', 'absolute']} right={[0, 16]} paddingY={4}>
        <ModalHeader></ModalHeader>
        <ModalCloseButton />
        <ModalBody paddingY={6}>
          <Slate
            //@ts-ignore
            ref={editorRef}
            editor={editor}
            value={value}
            initialValue={value}
            onChange={value => setValue(value)}
          >
            <Editable readOnly renderElement={renderElement} renderLeaf={renderLeaf} />
          </Slate>
        </ModalBody>
      </ModalContent>
    </Modal>
  )
}

const ImageTest = ({ attributes, children, element }) => {
  return (
    <div {...attributes}>
      {children}
      <div
        contentEditable={false}
        //@ts-ignore
        className={css`
          position: relative;
        `}
      >
        <Image
          src={element.url}
          alt='image'
          css={{
            display: 'block'
          }}
        />
      </div>
    </div>
  )
}

const Element = props => {
  const { attributes, children, element } = props

  switch (element.type) {
    case 'image':
      return <ImageTest {...props} />
    case 'block-quote':
      return (
        <Text as='cite' {...attributes}>
          {children}
        </Text>
      )
    case 'bulleted-list':
      return (
        <UnorderedList>
          <ListItem {...attributes}>{children}</ListItem>
        </UnorderedList>
      )
    case 'heading-one':
      return (
        <Heading size='lg' {...attributes}>
          {children}
        </Heading>
      )
    case 'heading-two':
      return (
        <Heading size='md' {...attributes}>
          {children}
        </Heading>
      )
    case 'list-item':
      return <li {...attributes}>{children}</li>
    case 'numbered-list':
      return (
        <OrderedList>
          <ListItem {...attributes}>{children}</ListItem>
        </OrderedList>
      )
    default:
      return (
        <Text textAlign='justify' {...attributes}>
          {children}
        </Text>
      )
  }
}

const Leaf = ({ attributes, children, leaf }: any) => {
  if (leaf.bold) {
    children = <Text as='b'>{children}</Text>
  }

  if (leaf.code) {
    children = <Text as='kbd'>{children}</Text>
  }

  if (leaf.italic) {
    children = <Text as='i'>{children}</Text>
  }

  if (leaf.underline) {
    children = <Text as='u'>{children}</Text>
  }

  return <span {...attributes}>{children}</span>
}

export default ModalAviso
