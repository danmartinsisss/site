import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  SimpleGrid,
  Stack,
  Text,
  UseDisclosureProps,
} from "@chakra-ui/react";
import { jsPDF } from "jspdf";

type servicosRelacionadosProps = {
  chave: string;
  livro: string;
  descricao: string;
};

type CertidaoRegistroProps = {
  protocolo: Number;
  solicitante: String;
  etapaDescricaoWeb: String;
  previsaoEntrega: String;
  dataInicial: String;
  servicosRelacionadosModel: Array<servicosRelacionadosProps>;
};

const ModalCertidaoRegistro = ({ isOpen, onClose }: UseDisclosureProps) => {
  const [dataCertidaoRegistro, setDataCertidaoRegistro] =
    useState<CertidaoRegistroProps>({
      protocolo: null,
      solicitante: "",
      etapaDescricaoWeb: "",
      previsaoEntrega: "",
      dataInicial: "",
      servicosRelacionadosModel: [],
    });

  useEffect(() => {
    const dataCertidaoRegistro = JSON.parse(
      localStorage.getItem("certidaoRegistro")
    );
    dataCertidaoRegistro && setDataCertidaoRegistro(dataCertidaoRegistro[0]);
  }, [isOpen]);

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} size="3xl">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Consulta Certidão Registro</ModalHeader>
          <ModalCloseButton />

          <ModalBody>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Protocolo
                </Text>
                <span>{dataCertidaoRegistro?.protocolo}</span>
              </Stack>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Status
                </Text>
                <span>{dataCertidaoRegistro?.etapaDescricaoWeb}</span>
              </Stack>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Data retirada
                </Text>
                <span>
                  {dataCertidaoRegistro?.previsaoEntrega
                    ?.split("-")
                    .reverse()
                    .join("/") || "-"}
                </span>
              </Stack>
            </SimpleGrid>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Data do pedido
                </Text>
                <span>
                  {dataCertidaoRegistro?.dataInicial
                    ?.split("-")
                    .reverse()
                    .join("/")}
                </span>
              </Stack>
              <Stack mb={4}>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Solicitante
                </Text>
                <span>{dataCertidaoRegistro?.solicitante}</span>
              </Stack>
            </SimpleGrid>
            <SimpleGrid columns={4} mb={8}>
              <Stack gridColumnStart={1} gridColumnEnd={3}>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Descrição
                </Text>
                {dataCertidaoRegistro?.servicosRelacionadosModel?.map(
                  (servico: servicosRelacionadosProps, index) => {
                    return <Text key={index}>{servico.descricao}</Text>;
                  }
                )}
              </Stack>
            </SimpleGrid>
          </ModalBody>

          <ModalFooter>
            <Button variant="ghost" onClick={onClose}>
              Fechar
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};

export default ModalCertidaoRegistro;
