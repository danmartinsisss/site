import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  SimpleGrid,
  Stack,
  Text,
  UseDisclosureProps,
} from "@chakra-ui/react";

type CertidaoTitulosDocumentosProps = {
  protocolo: Number;
  statusAndamento: String;
  dataEntrega: String;
  dataEntrada: String;
};

const ModalCertidaoTitulosDocumentos = ({
  isOpen,
  onClose,
}: UseDisclosureProps) => {
  const [dataCertidaoTitulosDocumentos, setDataCertidaoTitulosDocumentos] =
    useState<CertidaoTitulosDocumentosProps>({
      protocolo: null,
      statusAndamento: "",
      dataEntrega: "",
      dataEntrada: "",
    });

  useEffect(() => {
    const dataCertidaoTitulosDocumentos = JSON.parse(
      localStorage.getItem("certidaoTitulosDocumentos")
    );
    dataCertidaoTitulosDocumentos &&
      setDataCertidaoTitulosDocumentos(dataCertidaoTitulosDocumentos);
  }, [isOpen]);

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} size="3xl">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Consulta Certidão Titulos e Documentos</ModalHeader>
          <ModalCloseButton />

          <ModalBody>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Protocolo
                </Text>
                <span>{dataCertidaoTitulosDocumentos?.protocolo}</span>
              </Stack>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Status
                </Text>
                <span>{dataCertidaoTitulosDocumentos?.statusAndamento}</span>
              </Stack>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Data retirada
                </Text>
                <span>
                  {dataCertidaoTitulosDocumentos?.dataEntrega
                    ?.split("-")
                    .reverse()
                    .join("/") || "-"}
                </span>
              </Stack>
            </SimpleGrid>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize="sm"
                  fontWeight="bold"
                  _after={{
                    content: '""',
                    display: "block",
                    position: "absolute",
                    width: "1.75rem",
                    height: "0.1rem",
                    background: "darkgrey",
                  }}
                  mb={2}
                >
                  Data do pedido
                </Text>
                <span>
                  {dataCertidaoTitulosDocumentos?.dataEntrada
                    ?.split("-")
                    .reverse()
                    .join("/")}
                </span>
              </Stack>
            </SimpleGrid>
          </ModalBody>

          <ModalFooter>
            <Button variant="ghost" onClick={onClose}>
              Fechar
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};

export default ModalCertidaoTitulosDocumentos;
