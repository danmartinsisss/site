import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  SimpleGrid,
  Stack,
  Text,
  UseDisclosureProps
} from '@chakra-ui/react'
import { jsPDF } from 'jspdf'
import React, { useEffect, useState } from 'react'

type servicosRelacionadosProps = {
  chave: string
  livro: string
  descricao: string
}

type exigenciaProps = {
  numeroExigencia: Number
  dataExigencia: String
  textoExigencia: String
}

type RegistroProps = {
  protocolo: Number
  solicitante: String
  etapaWeb: String
  prevEntrega: String
  dataInicial: String
  natureza: String
  outorgante: String
  outorgado: String
  apresentante: String
  exigencia: Array<exigenciaProps>
  servicosRelacionados: Array<servicosRelacionadosProps>
  aguardaReingresso: Boolean
  reingressar: Boolean
  disponibilidade: String
}

const ModalRegistro = ({ isOpen, onClose }: UseDisclosureProps) => {
  const [isLoading, setIsLoading] = useState(false)
  const [exigencia, setExigencia] = useState('')
  const [dataRegistro, setDataRegistro] = useState<RegistroProps>({
    protocolo: null,
    solicitante: '',
    etapaWeb: '',
    prevEntrega: '',
    dataInicial: '',
    natureza: '',
    outorgante: '',
    outorgado: '',
    apresentante: '',
    exigencia: [],
    servicosRelacionados: [],
    aguardaReingresso: null,
    reingressar: null,
    disponibilidade: ''
  })

  useEffect(() => {
    if (isOpen) {
      const storedData = localStorage.getItem('registro');
      if (storedData) {
        const dataRegistro = JSON.parse(storedData);
        console.log('Dados recuperados do localStorage:', dataRegistro);

        if (dataRegistro?.Exigencias?.length > 0) {
          const textoExigencia = dataRegistro.Exigencias[0]?.TextoExigencia || '';
          setExigencia(textoExigencia);
        } else {
          console.log('Nenhuma exigência encontrada no dataRegistro.');
        }

        setDataRegistro(dataRegistro);
      } else {
        console.error('Nenhum dado encontrado no localStorage');
      }
    }
  }, [isOpen]);

  const generatePdf = async () => {
    if (!exigencia) return;
    try {
      setIsLoading(true);

      const doc = new jsPDF();

      // Cabeçalho do documento
      doc.setFont('courier', '');
      doc.setFontSize(12);

      const marginLeft = 10;
      let currentY = 20;
      const lineSpacing = 5;
      const lineSpacing2 = 8;

      doc.text('REPÚBLICA FEDERATIVA DO BRASIL', 105, currentY, { align: 'center' });
      currentY += lineSpacing;
      doc.text('ESTADO DE MATO GROSSO - COMARCA DE SORRISO', 105, currentY, { align: 'center' });
      currentY += lineSpacing;
      doc.text('REGISTRO DE IMÓVEIS E DE TÍTULOS E DOCUMENTOS', 105, currentY, { align: 'center' });
      currentY += lineSpacing;

      // Detalhes do cartório
      doc.setFontSize(11);
      doc.text('CARTÓRIO 1º OFÍCIO DA COMARCA DE SORRISO', 105, currentY, { align: 'center' });
      currentY += lineSpacing;
      doc.text('Av. Blumenau, 2727 - Centro, Sorriso - MT', 105, currentY, { align: 'center' });
      currentY += lineSpacing2;
      doc.setFont('', '', 'bold');
      doc.text('NOTA DE DEVOLUÇÃO', marginLeft + 75, currentY);
      currentY += lineSpacing2;

      // Processa e insere o texto da exigência
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = exigencia;
      const paragraphs = tempDiv.querySelectorAll('p');

      doc.setFont('', 'normal');
      doc.setFontSize(10);

      paragraphs.forEach((p) => {
        const paragraphText = p.innerText.trim();
        const lines = doc.splitTextToSize(paragraphText, 190);
        lines.forEach((line) => {
          doc.text(line, marginLeft, currentY);
          currentY += lineSpacing;
          if (currentY > 280) {
            doc.addPage();
            currentY = 20;
          }
        });
        currentY += 4;
      });

      doc.output('dataurlnewwindow');
    } catch (e) {
      console.log(e);
    }
    setIsLoading(false);
  };

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} size='3xl'>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Consulta Registro</ModalHeader>
          <ModalCloseButton />

          <ModalBody>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Protocolo
                </Text>
                <span>{dataRegistro?.protocolo}</span>
              </Stack>
              <Stack>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Status
                </Text>
                <span>
                  {dataRegistro?.aguardaReingresso && dataRegistro?.reingressar
                    ? 'Em exigência'
                    : dataRegistro?.disponibilidade === 'Cancelado'
                    ? 'Cancelado'
                    : dataRegistro?.etapaWeb}
                </span>
              </Stack>
              <Stack>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Previsão de entrega
                </Text>
                <span>{dataRegistro?.prevEntrega?.split('-').reverse().join('/')}</span>
              </Stack>
            </SimpleGrid>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Data de abertura
                </Text>
                <span>{dataRegistro?.dataInicial?.split('-').reverse().join('/')}</span>
              </Stack>
              <Stack gridColumnStart={2} gridColumnEnd={4}>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Natureza
                </Text>
                <span>{dataRegistro?.natureza}</span>
              </Stack>
            </SimpleGrid>
            <Stack mb={4}>
              <Text
                fontSize='sm'
                fontWeight='bold'
                _after={{
                  content: '""',
                  display: 'block',
                  position: 'absolute',
                  width: '1.75rem',
                  height: '0.1rem',
                  background: 'darkgrey'
                }}
                mb={2}
              >
                Outorgado/Interessado
              </Text>
              <span>{dataRegistro?.outorgado}</span>
            </Stack>
            <Stack mb={4}>
              <Text
                fontSize='sm'
                fontWeight='bold'
                _after={{
                  content: '""',
                  display: 'block',
                  position: 'absolute',
                  width: '1.75rem',
                  height: '0.1rem',
                  background: 'darkgrey'
                }}
                mb={2}
              >
                Outorgante
              </Text>
              <span>{dataRegistro?.outorgante}</span>
            </Stack>
            <Stack mb={8}>
              <Text
                fontSize='sm'
                fontWeight='bold'
                _after={{
                  content: '""',
                  display: 'block',
                  position: 'absolute',
                  width: '1.75rem',
                  height: '0.1rem',
                  background: 'darkgrey'
                }}
                mb={2}
              >
                Apresentante
              </Text>
              <span>{dataRegistro?.apresentante}</span>
            </Stack>
             <SimpleGrid columns={4} mb={8}>
                  <Stack gridColumnStart={1} gridColumnEnd={3}>
                    <Text fontSize='sm' fontWeight='bold' mb={2}>
                      Matrícula / Registro Auxiliar / Transcrição
                    </Text>
                    {dataRegistro?.servicosRelacionados?.length > 0 
                      ? dataRegistro.servicosRelacionados.map(
                          (servico: servicosRelacionadosProps, index) => {
                            return <Text key={index}>{servico?.Chave || 'N/A'}</Text>
                          }
                        )
                      : <Text>N/A</Text>}
                  </Stack>
                  <Stack gridColumn={3}>
                    <Text fontSize='sm' fontWeight='bold' mb={2}>
                      Livro
                    </Text>
                    {dataRegistro?.servicosRelacionados?.length > 0 
                      ? dataRegistro.servicosRelacionados.map(
                          (servico: servicosRelacionadosProps, index) => {
                            return <Text key={index}>{servico?.Livro || 'N/A'}</Text>
                          }
                        )
                      : <Text>N/A</Text>}
                  </Stack>
                  <Stack>
                    <Text fontSize='sm' fontWeight='bold' mb={2}>
                      Descrição
                    </Text>
                    {dataRegistro?.servicosRelacionados?.length > 0 
                      ? dataRegistro.servicosRelacionados.map(
                          (servico: servicosRelacionadosProps, index) => {
                            return <Text key={index}>{servico?.Descricao || 'N/A'}</Text>
                          }
                        )
                      : <Text>N/A</Text>}
                  </Stack>
                </SimpleGrid>
            {dataRegistro?.exigencia?.length > 0 && (
              <div
                id='text'
                hidden
                dangerouslySetInnerHTML={{
                  __html: exigencia?.toString()
                }}
              ></div>
            )}
          </ModalBody>

<ModalFooter>
  {(dataRegistro?.disponibilidade === 'Cancelado' || dataRegistro?.etapaWeb === 'Em exigência') && (
    <Button isLoading={isLoading} colorScheme='blue' mr={3} onClick={generatePdf}>
      Exigência
    </Button>
  )}
  <Button variant='ghost' onClick={onClose}>
    Fechar
  </Button>
</ModalFooter>


        </ModalContent>
      </Modal>
    </>
  )
}

export default ModalRegistro
