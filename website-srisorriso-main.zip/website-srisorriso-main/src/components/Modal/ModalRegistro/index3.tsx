import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  SimpleGrid,
  Stack,
  Text,
  UseDisclosureProps
} from '@chakra-ui/react'
import { jsPDF } from 'jspdf'
import React, { useEffect, useState } from 'react'

type servicosRelacionadosProps = {
  chave: string
  livro: string
  descricao: string
}

type exigenciaProps = {
  numeroExigencia: Number
  dataExigencia: String
  textoExigencia: String
}

type RegistroProps = {
  protocolo: Number
  solicitante: String
  etapaWeb: String
  prevEntrega: String
  dataInicial: String
  natureza: String
  outorgante: String
  outorgado: String
  apresentante: String
  exigencia: Array<exigenciaProps>
  servicosRelacionados: Array<servicosRelacionadosProps>
  aguardaReingresso: Boolean
  reingressar: Boolean
  disponibilidade: String
}

const ModalRegistro = ({ isOpen, onClose }: UseDisclosureProps) => {
  const [isLoading, setIsLoading] = useState(false)
  const [exigencia, setExigencia] = useState('')
  const [dataRegistro, setDataRegistro] = useState<RegistroProps>({
    protocolo: null,
    solicitante: '',
    etapaWeb: '',
    prevEntrega: '',
    dataInicial: '',
    natureza: '',
    outorgante: '',
    outorgado: '',
    apresentante: '',
    exigencia: [],
    servicosRelacionados: [],
    aguardaReingresso: null,
    reingressar: null,
    disponibilidade: ''
  })

  useEffect(() => {
    const dataRegistro = JSON.parse(localStorage.getItem('registro'))

    if (dataRegistro?.exigencia) {
      const textoExigencia = dataRegistro.exigencia.slice(-1)[0].textoExigencia
      setExigencia(textoExigencia)
    }

    setDataRegistro(dataRegistro)
  }, [isOpen])

  const generatePdf = async () => {
    const text = document.getElementById('text')
    try {
      setIsLoading(true)
      text.hidden = false

      const doc = new jsPDF()

      doc.setFontSize(11)
      doc.text('CARTÓRIO 1º OFÍCIO DA COMARCA DE SORRISO', 60, 10)
      doc.text(
        'Registro de Imóveis e de Títulos e Documentos da Comarca de Sorriso',
        45,
        20
      )
      doc.text('Av. Blumenau, 2727 - Centro, Sorriso - MT', 70, 25)
      doc.setFont('', '', 'bold')
      doc.text('NOTA DE EXIGÊNCIA', 85, 35)

      let split = doc.splitTextToSize(text.innerText, 200)

      doc.setFont('', '', 'normal')
      doc.setFontSize(10)

      if (split.length > 55) {
        const partOne = split.slice(0, 55)
        doc.text(partOne, 5, 50)
        const partTwo = split.slice(55)
        doc.addPage()
        doc.text(partTwo, 5, 10)
      } else {
        doc.text(split, 5, 50)
      }

      doc.output('dataurlnewwindow')
    } catch (e) {
      console.log(e)
    }
    setIsLoading(false)
    text.hidden = true
  }

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} size='3xl'>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Consulta Registro</ModalHeader>
          <ModalCloseButton />

          <ModalBody>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Protocolo
                </Text>
                <span>{dataRegistro?.protocolo}</span>
              </Stack>
              <Stack>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Status
                </Text>
                <span>
                  {dataRegistro?.aguardaReingresso && dataRegistro?.reingressar
                    ? 'Em exigência'
                    : dataRegistro?.disponibilidade === 'Cancelado'
                    ? 'Cancelado'
                    : dataRegistro?.etapaWeb}
                </span>
              </Stack>
              <Stack>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Previsão de entrega
                </Text>
                <span>{dataRegistro?.prevEntrega?.split('-').reverse().join('/')}</span>
              </Stack>
            </SimpleGrid>
            <SimpleGrid columns={3} mb={8}>
              <Stack>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Data de abertura
                </Text>
                <span>{dataRegistro?.dataInicial?.split('-').reverse().join('/')}</span>
              </Stack>
              <Stack gridColumnStart={2} gridColumnEnd={4}>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Natureza
                </Text>
                <span>{dataRegistro?.natureza}</span>
              </Stack>
            </SimpleGrid>
            <Stack mb={4}>
              <Text
                fontSize='sm'
                fontWeight='bold'
                _after={{
                  content: '""',
                  display: 'block',
                  position: 'absolute',
                  width: '1.75rem',
                  height: '0.1rem',
                  background: 'darkgrey'
                }}
                mb={2}
              >
                Outorgado/Interessado
              </Text>
              <span>{dataRegistro?.outorgado}</span>
            </Stack>
            <Stack mb={4}>
              <Text
                fontSize='sm'
                fontWeight='bold'
                _after={{
                  content: '""',
                  display: 'block',
                  position: 'absolute',
                  width: '1.75rem',
                  height: '0.1rem',
                  background: 'darkgrey'
                }}
                mb={2}
              >
                Outorgante
              </Text>
              <span>{dataRegistro?.outorgante}</span>
            </Stack>
            <Stack mb={8}>
              <Text
                fontSize='sm'
                fontWeight='bold'
                _after={{
                  content: '""',
                  display: 'block',
                  position: 'absolute',
                  width: '1.75rem',
                  height: '0.1rem',
                  background: 'darkgrey'
                }}
                mb={2}
              >
                Apresentante
              </Text>
              <span>{dataRegistro?.apresentante}</span>
            </Stack>
            <SimpleGrid columns={4} mb={8}>
              <Stack gridColumnStart={1} gridColumnEnd={3}>
                <Text
                  fontSize='sm'
                  fontWeight='bold'
                  _after={{
                    content: '""',
                    display: 'block',
                    position: 'absolute',
                    width: '1.75rem',
                    height: '0.1rem',
                    background: 'darkgrey'
                  }}
                  mb={2}
                >
                  Matrícula / Registro Auxiliar / Transcrição
                </Text>
                {dataRegistro?.servicosRelacionados?.map(
                  (servico: servicosRelacionadosProps, index) => {
                    return <Text key={index}>{servico.chave}</Text>
                  }
                )}
              </Stack>
              <Stack gridColumn={3}>
                <Text fontSize='sm' fontWeight='bold' mb={2}>
                  Livro
                </Text>
                {dataRegistro?.servicosRelacionados?.map(
                  (servico: servicosRelacionadosProps, index) => {
                    return <Text key={index}>{servico.livro}</Text>
                  }
                )}
              </Stack>
              <Stack>
                <Text fontSize='sm' fontWeight='bold' mb={2}>
                  Descrição
                </Text>
                {dataRegistro?.servicosRelacionados?.map(
                  (servico: servicosRelacionadosProps, index) => {
                    return <Text key={index}>{servico.descricao}</Text>
                  }
                )}
              </Stack>
            </SimpleGrid>
            {dataRegistro?.exigencia?.length > 0 && (
              <div
                id='text'
                hidden
                dangerouslySetInnerHTML={{
                  __html: exigencia?.toString()
                }}
              ></div>
            )}
          </ModalBody>

          <ModalFooter>
            {(dataRegistro?.aguardaReingresso &&
              dataRegistro?.reingressar &&
              dataRegistro?.exigencia) ||
            (dataRegistro?.disponibilidade === 'Cancelado' && dataRegistro?.exigencia) ? (
              <Button isLoading={isLoading} colorScheme='blue' mr={3} onClick={generatePdf}>
                Exigência
              </Button>
            ) : null}
            <Button variant='ghost' onClick={onClose}>
              Fechar
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  )
}

export default ModalRegistro
