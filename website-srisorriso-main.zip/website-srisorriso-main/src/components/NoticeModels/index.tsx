import { DeleteIcon } from '@chakra-ui/icons'
import { Flex, IconButton, List, ListItem, Text, useDisclosure } from '@chakra-ui/react'
import axios from 'axios'
import React, { useEffect, useState } from 'react'

export const NoticeModels = ({ data, setNotice }) => {
  const { onToggle } = useDisclosure()
  const [models, setModels] = useState([])

  useEffect(() => {
    setModels(data)
  }, [data, onToggle])

  const handleDeleteModel = async (id: string) => {
    await axios
      .get('/api/firebase/deleteModel', {
        params: { id }
      })
      .then(function (response) {
        console.log(response.statusText)
      })
      .catch(error => {
        console.log(error)
      })
      .finally(() => {
        onToggle()
      })
  }

  return (
    <Flex my={6}>
      <List w='full' spacing={1}>
        {models?.map((model, index) => {
          return (
            <ListItem
              key={index}
              display='flex'
              justifyContent='space-between'
              alignItems='center'
              p={2}
              bgColor='white'
              border='1px'
              borderColor='gray.300'
              onClick={() => setNotice(model.data)}
              _hover={{ cursor: 'pointer' }}
            >
              <Text isTruncated>{model.data?.title}</Text>
              <IconButton
                aria-label='Delete Button'
                icon={<DeleteIcon />}
                onClick={() => handleDeleteModel(model.id)}
              />
            </ListItem>
          )
        })}
      </List>
    </Flex>
  )
}
