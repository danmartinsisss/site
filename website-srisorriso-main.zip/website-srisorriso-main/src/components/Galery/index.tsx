import axios from 'axios'
import React, { useEffect, useState } from 'react'
import ImageGallery from 'react-image-gallery'
import 'react-image-gallery/styles/css/image-gallery.css'

const exampleImages = [
  {
    original: 'https://picsum.photos/id/1018/1000/600/',
    thumbnail: 'https://picsum.photos/id/1018/250/150/'
  },
  {
    original: 'https://picsum.photos/id/1015/1000/600/',
    thumbnail: 'https://picsum.photos/id/1015/250/150/'
  },
  {
    original: 'https://picsum.photos/id/1019/1000/600/',
    thumbnail: 'https://picsum.photos/id/1019/250/150/'
  }
]

const Galery = () => {
  const [images, setImages] = useState([])

  useEffect(() => {
    async function getImagesData() {
      const response = await axios.get('/api/firebase/getImagesData')

      let imagesData = []
      response.data.forEach(data => {
        imagesData.push({ id: data.id, data: JSON.parse(data.data.imageData) })
      })

      let imagesUrl = []
      imagesData.forEach(image => {
        const [, url] = image.data.url.split('http://')
        imagesUrl.push({
          original: `https://${url}`,
          thumbnail: `https://${url}`
        })
      })

      setImages(imagesUrl)
    }

    getImagesData()
  }, [])

  if (images.length === 0) {
    return <div>Loading...</div>
  }

  return (
    <ImageGallery
      lazyLoad
      items={images}
      showBullets={true}
      showIndex={true}
      showThumbnails={true}
      showPlayButton={false}
    />
  )
}

export default Galery
