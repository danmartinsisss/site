import React from "react";
//@ts-ignore
import { useOpenWeather } from "react-open-weather";

const Weather = () => {
  const { data } = useOpenWeather({
    key: "26b49cf2ccac762fb05ff57e45185890",
    lat: "-12.537645698766411",
    lon: "-55.72855729691969",
    unit: "metric", // values are (metric, standard, imperial)
  });

  return (
    <span>{data ? `${data?.current?.temperature?.current} ºC` : "Loading..."}</span>
  );
};

export default Weather;
