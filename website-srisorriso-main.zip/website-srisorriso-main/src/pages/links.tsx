import { Box, Container, Divider, Heading, Image, Link, SimpleGrid } from '@chakra-ui/react'
import React from 'react'
import { Layout } from '../components/Layout'
import { linksUteis } from '../service/_linksUteis'

type LinkProps = {
  href: string
  image: string
  alt: string
}

const Links = () => {
  return (
    <Layout>
      <Container
        maxW='container.lg'
        bgColor='white'
        boxShadow='lg'
        rounded={6}
        mt={6}
        mb={16}
        p={4}
      >
        <Heading fontWeight='thin' textAlign='center' mb={4} color='GrayText'>
          LINKS ÚTEIS
        </Heading>
        <Divider />
        <Container maxW='container.md' my={4}>
          <SimpleGrid columns={[1, 2, 4]} spacing={10}>
            {linksUteis.map((link: LinkProps) => (
              <Link key={link.alt} href={link.href} isExternal>
                <Box
                  height='140px'
                  bgColor='#F7F7F7'
                  boxShadow='base'
                  borderRadius={8}
                  p={4}
                  display='flex'
                  justifyContent='center'
                  alignItems='center'
                >
                  {link.image ? (
                    <Image src={link.image} alt={link.alt} maxH='110' />
                  ) : (
                    link.alt
                  )}
                </Box>
              </Link>
            ))}
          </SimpleGrid>
        </Container>
      </Container>
    </Layout>
  )
}

export default Links
