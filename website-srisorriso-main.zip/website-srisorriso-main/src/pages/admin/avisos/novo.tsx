import React, { useEffect } from 'react'
import { Box, Container, Heading } from '@chakra-ui/react'
import AdminLayout from '../../../components/AdminLayout'
import ModelCreate from '../../../components/ModelCreate'

function Novo() {
  useEffect(() => {
    //@ts-ignore
    const user = JSON.parse(localStorage.getItem('user'))
    if (!user) {
      window.location.href = '/admin/login'
    }
  }, [])

  return (
    <AdminLayout>
      <Container maxW='container.xl'>
        <Box bg='gray.50' borderRadius={6} padding={4}>
          <Heading size='lg'>Criar modelo de aviso</Heading>
          <ModelCreate />
        </Box>
      </Container>
    </AdminLayout>
  )
}

export default Novo
