import React, { useEffect, useState } from "react";
import { Box, CircularProgress, Container, Heading } from "@chakra-ui/react";
import AdminLayout from "../../../components/AdminLayout";
import { NoticeModels } from "../../../components/NoticeModels";
import RichText from "../../../components/RichText";
import axios from "axios";

type NoticeProps = {
  title: string;
  text: string;
  isActivated: string;
};

function Publicar() {
  const [models, setModels] = useState<NoticeProps | null>(null);
  const [currentNotice, setCurrentNotice] = useState<NoticeProps | null>(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) {
      window.location.href = "/admin/login";
    }
  }, []);

  useEffect(() => {
    async function getNoticesData() {
      const [modelsData, currentNoticeData] = await Promise.all([
        axios.get("/api/firebase/getModels"),
        axios.get("/api/firebase/getCurrentNotice"),
      ]);

      setModels(modelsData.data);
      setCurrentNotice(currentNoticeData.data);
    }

    getNoticesData();
  }, []);

  if (!models || !currentNotice) {
    return (
      <AdminLayout>
        <Container maxW="container.xl">
          <CircularProgress isIndeterminate />
        </Container>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <Container maxW="container.xl">
        <Box bg="gray.50" borderRadius={6} padding={4}>
          <Heading size="lg">Publicar aviso</Heading>
          <RichText data={currentNotice} />
          <Heading size="lg">Modelos</Heading>
          <NoticeModels data={models} setNotice={setCurrentNotice} />
        </Box>
      </Container>
    </AdminLayout>
  );
}

export default Publicar;
