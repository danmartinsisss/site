import { DeleteIcon } from '@chakra-ui/icons'
import {
  Box,
  Button,
  Container,
  Flex,
  Heading,
  HStack,
  IconButton,
  Input,
  useDisclosure
} from '@chakra-ui/react'
import axios from 'axios'
import { Image } from 'cloudinary-react'
import React, { useEffect, useState } from 'react'
import AdminLayout from '../../../components/AdminLayout'

function Galeria() {
  const { onToggle } = useDisclosure()
  const [uploadImage, setUploadImage] = useState(null)
  const [images, setImages] = useState([])

  useEffect(() => {
    async function getImagesData() {
      const response = await axios.get('/api/firebase/getImagesData')

      let images = []
      response.data.forEach(data => {
        images.push({ id: data.id, data: JSON.parse(data.data.imageData) })
      })

      setImages(images)
    }

    getImagesData()
  }, [onToggle])

  async function handleUploadImage() {
    const data = new FormData()
    data.append('file', uploadImage)
    data.append('upload_preset', 'srisorriso')
    data.append('cloud_name', 'blitech-solucoes-em-ti')

    const response = await axios.post(
      'https://api.cloudinary.com/v1_1/blitech-solucoes-em-ti/image/upload',
      data
    )

    if (response.data) {
      await axios
        .get('/api/firebase/setImageData', {
          params: {
            image: response.data
          }
        })
        .then(res => console.log(res))
        .catch(error => console.log(error))
        .finally(() => {
          onToggle()
        })
    }
  }

  async function handleDeleteImage(id) {
    await axios
      .get('/api/firebase/deleteImage', {
        params: {
          id
        }
      })
      .then(res => console.log(res))
      .catch(error => console.log(error))
      .finally(() => {
        window.location.reload()
      })
  }

  return (
    <AdminLayout>
      <Container maxW='container.xl'>
        <Box bg='gray.50' borderRadius={6} padding={4} mb={8}>
          <Heading size='lg' mb={4}>
            Carregar foto
          </Heading>
          <Flex>
            <Input type='file' onChange={e => setUploadImage(e.target.files[0])} mr={8} />
            <Button colorScheme='blue' onClick={() => handleUploadImage()}>
              Enviar
            </Button>
          </Flex>
        </Box>
        <Box bg='gray.50' borderRadius={6} padding={4} mb={8}>
          <HStack spacing={10}>
            {images.map(image => (
              <Flex key={image.id} flexDir='column' alignItems='center'>
                <Box>
                  <Image
                    cloudName='blitech-solucoes-em-ti'
                    publicId={image.data.public_id}
                    width='300'
                  />
                </Box>
                <Box p={4}>
                  <IconButton
                    aria-label='Delete image'
                    icon={<DeleteIcon />}
                    variant='ghost'
                    color='red'
                    value={image.id}
                    onClick={e => handleDeleteImage(e.currentTarget.value)}
                  />
                </Box>
              </Flex>
            ))}
          </HStack>
        </Box>
      </Container>
    </AdminLayout>
  )
}

export default Galeria
