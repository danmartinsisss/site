import React from "react";
import axios from "axios";
import { useState } from "react";
import {
  Button,
  Flex,
  FormControl,
  Heading,
  Input,
  Text,
} from "@chakra-ui/react";

export default function Login() {
  const [isLoading, setIsLoading] = useState(false);
  const [hidden, setHidden] = useState(true);
  const [values, setValues] = useState({
    email: "",
    password: "",
  });

  const handleLogin = (event) => {
    event.preventDefault();
    try {
      setIsLoading(true);
      setHidden(true);

      axios
        .get("/api/firebase/auth", {
          params: {
            email: values?.email,
            password: values?.password,
          },
        })
        .then(async (response) => {
          localStorage.setItem("user", JSON.stringify(response.data));
          window.location.href = "/admin";
        })
        .catch((error) => {
          if (error.response.status === 403) {
            setHidden(false);
          }
        })
        .finally(() => {
          setIsLoading(false);
        });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Flex height="100vh" alignItems="center" justifyContent="center">
      <Flex
        boxShadow="xl"
        direction="column"
        background="gray.200"
        p={12}
        rounded={6}
      >
        <Heading mb={6} size="lg">
          Área restrita
        </Heading>
        <form onSubmit={handleLogin}>
          <FormControl isRequired>
            <Input
              placeholder="Usuário"
              variant="filled"
              type="email"
              mb={3}
              value={values.email}
              onChange={(event) =>
                setValues({ ...values, email: event.target.value })
              }
            />
          </FormControl>
          <FormControl isRequired>
            <Input
              placeholder="Senha"
              variant="filled"
              mb={2}
              type="password"
              value={values.password}
              onChange={(event) =>
                setValues({ ...values, password: event.target.value })
              }
            />
          </FormControl>
          <Text
            hidden={hidden}
            fontSize="xs"
            color="red.700"
            fontWeight="semibold"
          >
            Usuário ou senha incorreta!
          </Text>
          <Button isFullWidth mt={6} isLoading={isLoading} colorScheme="blue" type="submit">
            Entrar
          </Button>
        </form>
      </Flex>
    </Flex>
  );
}
