import { Container, StackDivider, VStack } from '@chakra-ui/react'
import React, { useEffect } from 'react'
import AdminLayout from '../../components/AdminLayout'

const Index = () => {
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'))
    if (!user) {
      window.location.href = '/admin/login'
    }
  }, [])

  return (
    <AdminLayout>
      <Container maxW='container.xl'>
        <VStack
          divider={<StackDivider borderTop='3px solid #bbb' />}
          align='stretch'
          spacing={4}
        ></VStack>
      </Container>
    </AdminLayout>
  )
}

export default Index
