import {
  Box,
  Container,
  Divider,
  Heading,
  Image,
  ListItem,
  SimpleGrid,
  Text,
  UnorderedList
} from '@chakra-ui/react'
import axios from 'axios'
import React, { useEffect, useRef } from 'react'
import { Layout } from '../components/Layout'

const Requerimentos = () => {
  const [requerimentosRI, setRequerimentosRI] = React.useState([])
  const [requerimentosRTD, setRequerimentosRTD] = React.useState([])
  const refRTD = useRef<HTMLDivElement>(null)
  const refCardRTD = useRef<HTMLDivElement>(null)
  const refRI = useRef<HTMLDivElement>(null)
  const refCardRI = useRef<HTMLDivElement>(null)

  useEffect(() => {
    async function getFiles() {
      const { data } = await axios.get('/api/requerimentos')

      setRequerimentosRI(data.ri.sort())
      setRequerimentosRTD(data.rtd.sort())
    }

    getFiles()
  }, [])

  const handleClickShowRTD = () => {
    refRTD.current.hidden = false
    refRI.current.hidden = true
  }

  const handleClickShowRI = () => {
    refRI.current.hidden = false
    refRTD.current.hidden = true
  }

  return (
    <Layout>
      <Container
        maxW='container.xl'
        bgColor='white'
        boxShadow='lg'
        rounded={6}
        mt={6}
        mb={16}
        p={4}
      >
        <Heading fontWeight='thin' textAlign='center' mb={4} color='GrayText'>
          Requerimentos
        </Heading>
        <Divider />
        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={10} marginLeft='10%' my={4}>
          <Box>
            <Box
              ref={refCardRI}
              display='flex'
              flexDir='column'
              alignItems='center'
              borderRadius={8}
              backgroundColor='whitesmoke'
              paddingY={4}
              paddingX={8}
              maxW={325}
              _hover={{ transform: 'scale(1.05)', boxShadow: 'lg' }}
              transition='all 0.2s'
              onClick={handleClickShowRI}
            >
              <Text
                fontWeight='semibold'
                textAlign='center'
                fontSize='1.25rem'
                mb={4}
                color='GrayText'
              >
                Registro de Imóveis
              </Text>
              <Image
                src='/images/ri.png'
                alt=''
                maxW={240}
                filter='drop-shadow(0 0 0.4rem rgba(84,87,94,0.7))'
              />
            </Box>
            <Box ref={refRI} hidden mt={4}>
              <Text fontWeight='semibold' fontSize='md'>
                Requerimentos de Registro de Imóveis
              </Text>
              <UnorderedList p={4} spacing={4}>
                {requerimentosRI.map(requerimento => (
                  <ListItem
                    key={requerimento}
                    css={{ ':first-letter': { textTransform: 'capitalize' } }}
                  >
                    <a href={`/files/requerimentos/ri/${requerimento}`}>
                      {requerimento.replaceAll('_', ' ').replace('.doc', '')}
                    </a>
                  </ListItem>
                ))}
              </UnorderedList>
            </Box>
          </Box>
          <Box>
            <Box
              ref={refCardRTD}
              display='flex'
              flexDir='column'
              alignItems='center'
              borderRadius={8}
              backgroundColor='whitesmoke'
              paddingY={4}
              paddingX={8}
              maxW={325}
              _hover={{ transform: 'scale(1.05)', boxShadow: 'lg' }}
              transition='all 0.2s'
              onClick={handleClickShowRTD}
            >
              <Text
                fontWeight='semibold'
                textAlign='center'
                fontSize='1.25rem'
                mb={4}
                color='GrayText'
              >
                Títulos e Documentos
              </Text>
              <Image
                src='/images/rtd.png'
                alt=''
                maxW={260}
                filter='drop-shadow(0 0 0.4rem rgba(84,87,94,0.7))'
              />
            </Box>
            <Box ref={refRTD} hidden mt={4}>
              <Text fontWeight='semibold' fontSize='md'>
                Requerimentos para Registro em Títulos e Documentos
              </Text>
              <UnorderedList p={5} spacing={4}>
                {requerimentosRTD.map(requerimento => (
                  <ListItem
                    key={requerimento}
                    css={{ ':first-letter': { textTransform: 'capitalize' } }}
                  >
                    <a href={`/files/requerimentos/rtd/${requerimento}`}>
                      {requerimento.replace('.doc', '').replaceAll('_', ' ')}
                    </a>
                  </ListItem>
                ))}
              </UnorderedList>
            </Box>
          </Box>
        </SimpleGrid>
      </Container>
    </Layout>
  )
}

export default Requerimentos
