import { Image } from "@chakra-ui/react";

export default function Teste() {
  return (
    <div>
      <Image src="https://storage.googleapis.com/download/storage/v1/b/website-srisorriso.appspot.com/o/background.jpeg?generation=1635342120422121&alt=media" />
    </div>
  );
}
