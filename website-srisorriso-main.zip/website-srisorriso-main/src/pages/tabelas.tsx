import {
  Container,
  Divider,
  Heading,
  Link,
  Stack,
  Text
} from "@chakra-ui/react";
import React from "react";
import { Layout } from "../components/Layout";

export default function Tabelas() {
  return (
    <Layout>
      <Container
        maxW="container.lg"
        bgColor="white"
        boxShadow="lg"
        rounded={6}
        mt={6}
        mb={16}
        p={4}
      >
        <Heading fontWeight="thin" textAlign="center" mb={4} color="GrayText">
          TABELAS DE EMOLUMENTOS
        </Heading>
        <Divider />
        <Stack my={6} spacing={6}>
          <Text>
            Em 01 de Janeiro de 2024, entrou em vigor a nova Tabela de Emolumentos no Estado de Mato Grosso, conforme Provimento nº 38/2023, da Corregedoria-Geral da Justiça de Mato Grosso.
          </Text>
          <Text>
            <Link
              color="blue.500"
              href="/files/Provimento n. 38-2023-CGJ Republicado.pdf"
              isExternal
            >
              Tabela de emolumentos
            </Link>{" "}
            (Lei Estadual n.º 7.550, de 03/12/2001)
          </Text>
          <Text>
            <Link
              color="blue.500"
              href="/files/Emolumentos_RI-RTD.pdf"
              isExternal
            >
              Tabela de emolumentos pelo registro de imóveis e de títulos e
              documentos
            </Link>{" "}
            (Faixas de valores nos termos do art. 2º, III, b, da Lei Federal n.º
            10.169, de 29/12/2000)
          </Text>
          <Text>
            <Link
              color="blue.500"
              href="/files/Emolumentos_Cedulas.pdf"
              isExternal
            >
              Tabela de emolumentos pelo registro de cédula de crédito
            </Link>{" "}
            (Faixas de valores nos termos do art. 2º, III, b, da Lei Federal n.º
            10.169, de 29/12/2000)
          </Text>
        </Stack>
      </Container>
    </Layout>
  );
}
