import { ExternalLinkIcon } from '@chakra-ui/icons'
import {
  Box,
  Container,
  Flex,
  Heading,
  HStack,
  Image,
  Link,
  SimpleGrid,
  Stack,
  Text,
  useDisclosure
} from '@chakra-ui/react'
import NextLink from 'next/link'
import React from 'react'
import {
  FaCalendar,
  FaClipboard,
  FaEnvelope,
  FaMapMarkerAlt,
  FaPhone,
  FaWhatsappSquare,
} from 'react-icons/fa'
import Consultas from '../components/Consultas'
import Galery from '../components/Galery'
import { Layout } from '../components/Layout'
import ModalAviso from '../components/Modal/ModalAviso'
import ModalDuvidas from '../components/Modal/ModalDuvidas'
import ServiceCards from '../components/ServiceCards'

export default function Home() {
  const modalDuvidas = useDisclosure()

  return (
    <Layout>
<Container
  maxW="full"
  display="flex"
  justifyContent="center" // Centraliza o conteúdo horizontalmente
  backgroundColor="whiteAlpha.600"
  borderBottom="1px"
  borderColor="gray.200"
  py={50} // Ajusta o padding superior e inferior para diminuir o espaço
  px={50} // Ajusta o padding lateral.
>
  <Link href="https://registradores.onr.org.br" isExternal>
    <Image
      src="/images/saec.jpeg"
      alt="Serviço de Atendimento Eletrônico Compartilhados"
      width="1248px" // Define a largura exata do banner
      height="168px" // Define a altura exata do banner
      objectFit="cover" // Ajusta a imagem para cobrir toda a área definida
      _hover={{
        transform: "scale(1.1)"
      }}
      transition="all 0.2s"
      css={{
        boxShadow: "12px 12px 40px 0px rgba(0,0,0,0.75)"
      }}
    />
  </Link>
</Container>

      <ServiceCards onOpenDuvidas={modalDuvidas.onOpen} />
      <Flex
        direction='column'
        bgColor='#203864'
        color='white'
        align='center'
        py={8}
        mb={16}
      >
        <Heading fontWeight='semibold' textTransform='uppercase' textAlign='center' mb={6}>
          Consulta de Protocolo
        </Heading>
        <Consultas />
      </Flex>

      <Container maxW='container.md' flexDir='column' color='#3a4856' mb={16}>
        <Heading fontWeight='semibold' textTransform='uppercase' textAlign='center' mb={6}>
          Galeria de Fotos
        </Heading>
        <Galery />
      </Container>

      <Container maxW='container.xl' color='#3a4856' mb={16}>
        <SimpleGrid columns={[1, 2]} spacing={4}>
          <Box>
            <Heading mb={6}>Contato e Localização</Heading>
            <Stack spacing={6}>
              <HStack>
                <FaPhone />
                <Text fontWeight='semibold'>Telefone: +55 66 3544-3030</Text>
              </HStack>
              <HStack>
                <FaWhatsappSquare />
                <Text fontWeight='semibold'>
                  <a href="https://api.whatsapp.com/send?phone=5566999272063&text=Olá!">Whatsapp +55 66 99927-2063</a>
                </Text>
              </HStack>
              <HStack>
                <FaEnvelope />
                <Text fontWeight='semibold'>E-mail: srisorriso@terra.com.br</Text>
              </HStack>
              <HStack>
                <FaMapMarkerAlt />
                <Text fontWeight='semibold'>
                  Endereço: Av. Blumenau, 2727 - Centro, Sorriso - MT, CEP: 78.890-168
                </Text>
              </HStack>
              <NextLink href='/contato'>
                <HStack>
                  <FaClipboard />
                  <Text
                    fontWeight='semibold'
                    _hover={{ cursor: 'pointer', textDecoration: 'underline' }}
                  >
                    Formulário online <ExternalLinkIcon />
                  </Text>
                </HStack>
              </NextLink>
            </Stack>
          </Box>
          <Box h={['200px', '600px']}>
            <iframe
              src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3894.5553084544363!2d-55.72836378431032!3d-12.54559179113638!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x93a0b3987f548165%3A0x1ebcbce1ba6f5d08!2zQ2FydMOzcmlvIGRvIDHCuiBPZsOtY2lvIFNvcnJpc28!5e0!3m2!1spt-BR!2sbr!4v1629666497468!5m2!1spt-BR!2sbr'
              width='100%'
              height='100%'
              loading='lazy'
              allowFullScreen
            />
          </Box>
        </SimpleGrid>
      </Container>

      {/* Modais */}
      <ModalDuvidas isOpen={modalDuvidas.isOpen} onClose={modalDuvidas.onClose} />
      <ModalAviso />
    </Layout>
  )
}
