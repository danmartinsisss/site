import React from "react";
import {
  Container,
  Heading,
  Divider,
  Text,
  Stack,
  Link,
} from "@chakra-ui/layout";
import { ExternalLinkIcon } from "@chakra-ui/icons";
import { Layout } from "../components/Layout";

const Cartilha = () => {
  return (
    <Layout>
      <Container
        maxW="container.lg"
        bgColor="white"
        boxShadow="lg"
        rounded={6}
        mt={6}
        mb={16}
        p={4}
      >
        <Heading fontWeight="thin" textAlign="center" mb={4} color="GrayText">
          Cartilha
        </Heading>
        <Divider />
        <Stack spacing={5} p={4} my={8}>
          <Text>Caro leitor,</Text>
          <Text css={{ textIndent: "50px" }} textAlign="justify">
            Registrar um ato ou negócio significa prevenir-se contra
            questionamentos inconvenientes e lesivos a direitos conquistados,
            bem como contra efetivos danos a esses direitos. Apesar do conhecido
            pensamento “melhor prevenir que remediar”, de fato não vivenciamos a
            cultura da prevenção.
          </Text>
          <Text css={{ textIndent: "50px" }} textAlign="justify">
            É bem mais comum procurarmos o médico depois da doença instalada do
            que para preveni-la, mesmo sabendo que o preço que pagamos por essa
            postura é normalmente mais alto. Para quase tudo há prevenção, mas
            para muitas coisas não há remédio. Infelizmente, a mesma postura é
            adotada quando tratamos de negócios ou atos jurídicos das nossas
            vidas particulares.
          </Text>
          <Text css={{ textIndent: "50px" }} textAlign="justify">
            Com o crescimento da sociedade e, conseqüentemente, do volume e da
            complexidade dos negócios, foram criados diversos tipos de registros
            públicos para prevenir problemas e garantir direitos. Porém, muitos
            desses serviços colocados à disposição do cidadão não são
            efetivamente utilizados, por desconhecimento de seus valiosos
            efeitos.
          </Text>
          <Text css={{ textIndent: "50px" }} textAlign="justify">
            Ao ler esta Cartilha, você perceberá que os Cartórios Extrajudiciais
            são de grande utilidade para sua vida, assim como de extrema
            importância para toda a sociedade. Os Cartórios Extrajudiciais têm
            tudo a ver com a efetivação de certos direitos e deveres
            relacionados principalmente a cidadania e ao direito de propriedade
            consagrado na Constituição Federal.
          </Text>
          <Text css={{ textIndent: "50px" }} textAlign="justify">
            Por essa razão, é com imenso prazer que a Corregedoria-Geral da
            Justiça do Estado de Mato Grosso e a Associação dos Notários e
            Registrados do Estado de Mato Grosso lançam a{" "}
            <Link
              href="http://fm.srisorriso.com.br/plugins/filemanager/files/cartilha_extrajudicial/Cartilha_Extrajudicial-compressed.pdf"
              isExternal
              color="blue.600"
              fontWeight="semibold"
            >
              Cartilha dos Cartórios Extrajudiciais <ExternalLinkIcon />.
            </Link>
          </Text>
          <Text as="em" color="GrayText" fontWeight="semibold">
            Corregedoria-Geral da Justiça e Anoreg-MT
          </Text>
        </Stack>
      </Container>
    </Layout>
  );
};

export default Cartilha;
