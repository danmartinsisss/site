import React, { useState } from "react";
import axios from "axios";
import {
  Alert,
  Box,
  Button,
  Container,
  Divider,
  FormControl,
  FormLabel,
  Heading,
  Input,
  SlideFade,
  Stack,
  Textarea,
  useDisclosure,
} from "@chakra-ui/react";
import { Layout } from "../components/Layout";

const Contato = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [isLoading, setIsLoading] = useState(false);
  const [alert, setAlert] = useState({
    status: "success",
    title: "",
  });
  const [values, setValues] = useState({
    name: "",
    phone: "",
    email: "",
    message: "",
  });

  const sendMail = async (event: any) => {
    event.preventDefault();
    try {
      setIsLoading(true);
      axios
        .get("/api/mail/sendMail", {
          params: {
            name: values.name,
            phone: values.phone,
            email: values.email,
            message: values.message,
          },
        })
        .then(function (response) {
          onOpen();
          setAlert({
            ...alert,
            status: "success",
            title: "Mensagem enviada com sucesso!",
          });
        })
        .catch(function (error) {
          onOpen();
          setAlert({
            ...alert,
            status: "error",
            title: "Falha no envio da mensagem.",
          });
        })
        .finally(() => {
          setIsLoading(false);
          setValues({ ...values, name: "", phone: "", email: "", message: "" });
          setTimeout(() => {
            onClose();
          }, 5000);
        });
    } catch (e) {
      console.log(e);
    }
  };

  const handleChange = (prop: any) => (event: any) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  return (
    <Layout>
      <Container
        maxW="container.lg"
        bgColor="white"
        boxShadow="lg"
        rounded={6}
        mt={6}
        mb={16}
        p={4}
      >
        <Heading fontWeight="thin" textAlign="center" mb={4} color="GrayText">
          Contato
        </Heading>
        <Divider />
        <SlideFade in={isOpen} offsetY="20px">
          <Alert
            //@ts-ignore
            status={alert.status}
            variant="top-accent"
          >
            {alert.title}
          </Alert>
        </SlideFade>
        <form onSubmit={sendMail}>
          <Box>
            <Stack p={4} spacing={4} maxW="lg" m="auto">
              <FormControl id="name" isRequired>
                <FormLabel>Nome</FormLabel>
                <Input
                  variant="filled"
                  placeholder="Nome"
                  value={values.name}
                  onChange={handleChange("name")}
                />
              </FormControl>
              <FormControl id="phone">
                <FormLabel>Telefone</FormLabel>
                <Input
                  variant="filled"
                  placeholder="Telefone"
                  type="phone"
                  value={values.phone}
                  onChange={handleChange("phone")}
                />
              </FormControl>
              <FormControl id="email">
                <FormLabel>E-mail</FormLabel>
                <Input
                  variant="filled"
                  placeholder="E-mail"
                  type="email"
                  value={values.email}
                  onChange={handleChange("email")}
                />
              </FormControl>
              <FormControl id="message" isRequired>
                <FormLabel>Mensagem</FormLabel>
                <Textarea
                  h="200px"
                  variant="filled"
                  placeholder="Mensagem"
                  value={values.message}
                  onChange={handleChange("message")}
                />
              </FormControl>
              <Button
                colorScheme="blue"
                type="submit"
                loadingText="Enviando"
                isLoading={isLoading}
              >
                Enviar
              </Button>
            </Stack>
          </Box>
        </form>
      </Container>
    </Layout>
  );
};

export default Contato;
