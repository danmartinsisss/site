import React from 'react'
import NextLink from 'next/link'
import Head from 'next/head'
import {
  Button,
  Divider,
  Flex,
  HStack,
  Image,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Stack,
  Text,
  VStack
} from '@chakra-ui/react'
import { HamburgerIcon } from '@chakra-ui/icons'
import Clock from 'react-live-clock'
import Weather from '../components/Weather'

export default function Index() {
  return (
    <>
      <Head>
        <title>1º Ofício de Sorriso - MT</title>
      </Head>
      <Flex width='100%' flexDir='column' position='fixed' zIndex={2}>
        <Flex
          py={4}
          justifyContent='space-around'
          alignItems='center'
          bgColor='#203864'
          display={['none', 'none', 'flex', 'flex']}
        />
        <Divider h={1} bgColor='white' display={['none', 'none', 'flex', 'flex']} />
        <Flex
          justifyContent='center'
          bgColor='rgba(32, 56, 100,0.5)'
          display={['none', 'none', 'flex', 'flex']}
        >
          <Stack direction='row' spacing={6} py={3}>
            <NextLink href='/home'>
              <Button color='white' variant='link' fontSize='sm'>
                Home
              </Button>
            </NextLink>
            <NextLink href='/institucional'>
              <Button color='white' variant='link' fontSize='sm'>
                Institucional
              </Button>
            </NextLink>
            <NextLink href='/links'>
              <Button color='white' variant='link' fontSize='sm'>
                Links úteis
              </Button>
            </NextLink>
            <NextLink href='/contato'>
              <Button color='white' variant='link' fontSize='sm'>
                Contato
              </Button>
            </NextLink>
          </Stack>
        </Flex>
        <Flex
          justifyContent='left'
          bgColor='rgba(75,120,155,0.7)'
          display={['flex', 'flex', 'none', 'none']}
        >
          <Menu>
            <MenuButton as={Button} variant='ghost' size='lg' colorScheme='blue'>
              <HamburgerIcon color='white' />
            </MenuButton>
            <MenuList>
              <NextLink href='/home'>
                <MenuItem>Home</MenuItem>
              </NextLink>
              <NextLink href='/institucional'>
                <MenuItem>Institucional</MenuItem>
              </NextLink>
              <NextLink href='/links'>
                <MenuItem>Links úteis</MenuItem>
              </NextLink>
              <NextLink href='/contato'>
                <MenuItem>Contato</MenuItem>
              </NextLink>
            </MenuList>
          </Menu>
        </Flex>
      </Flex>
      <Flex
        height='100vh'
        bgImage="url('background.jpeg')"
        bgPosition='center'
        bgRepeat='no-repeat'
        bgSize='cover'
        filter='brightness(40%)'
      />
      <Flex w='100%' zIndex={2} bottom={0} position='absolute'>
        <HStack
          w='100%'
          py={4}
          px={16}
          justifyContent='space-between'
          alignItems='flex-end'
          display={['none', 'none', 'flex', 'flex']}
        >
          <Image
            src='logo.png'
            alt='Logo'
            maxW='150px'
            filter='drop-shadow(2px 4px 6px #121212)'
          />
          <HStack spacing='40px'>
            <VStack align='left'>
              <Text color='gray.400' fontSize='xs' fontWeight='semibold'>
                Horário local
              </Text>
              <Text color='white' fontSize='2xl' fontWeight='normal'>
                <Clock format='HH:mm' ticking={true} timezone='America/Cuiaba' />
              </Text>
            </VStack>
            <VStack align='left'>
              <Text color='gray.400' fontSize='xs' fontWeight='semibold'>
                Temperatura local
              </Text>
              <Text color='white' fontSize='2xl' fontWeight='normal'>
                <Weather />
              </Text>
            </VStack>
          </HStack>
        </HStack>
        <VStack
          w='100%'
          py={4}
          justifyContent='center'
          alignItems='center'
          display={['flex', 'flex', 'none', 'none']}
        >
          <HStack spacing='120px'>
            <VStack align='left'>
              <Text color='gray.400' fontSize='xs' fontWeight='semibold'>
                Horário local
              </Text>
              <Text color='white' fontSize='3xl' fontWeight='normal'>
                <Clock format='HH:mm' ticking={true} timezone='America/Cuiaba' />
              </Text>
            </VStack>
            <VStack align='left'>
              <Text color='gray.400' fontSize='xs' fontWeight='semibold'>
                Temperatura local
              </Text>
              <Text color='white' fontSize='3xl' fontWeight='normal'>
                <Weather />
              </Text>
            </VStack>
          </HStack>
        </VStack>
      </Flex>
    </>
  )
}
