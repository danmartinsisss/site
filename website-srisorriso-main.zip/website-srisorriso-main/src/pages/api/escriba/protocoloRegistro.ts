// src/pages/api/escriba/protocoloRegistro.ts
import https from 'https';
import type { NextApiRequest, NextApiResponse } from 'next';

const httpsAgent = new https.Agent({
  rejectUnauthorized: false,
});

async function getAccessToken() {
  const url = 'https://websystems.voxeldasti.com.br/api/authenticate';

  const credentials = {
    email: 'api@srisorriso.com.br',
    password: 's!qD7qLYZMdFTN',
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials),
      agent: httpsAgent,
    });

    if (!response.ok) {
      throw new Error(`Failed to authenticate: ${response.statusText}`);
    }

    const data = await response.json();
    return data.token;
  } catch (error) {
    console.error('Error fetching access token:', error);
    return null;
  }
}

export default async function protocoloRegistro(req: NextApiRequest, res: NextApiResponse) {
  const { protocolo } = req.query;

  const token = await getAccessToken();
  if (!token) {
    return res.status(500).json({ error: 'Unable to fetch access token' });
  }

  const url = `https://websystems.voxeldasti.com.br/api/register/protocolos-registro/numero-protocolo?protocolo=${protocolo}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      agent: httpsAgent,
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch data: ${response.statusText}`);
    }

    const data = await response.json();
    return res.status(200).json(data);
  } catch (error) {
    console.error('Error fetching data:', error);
    return res.status(500).json({ error: 'Error fetching data' });
  }
}
