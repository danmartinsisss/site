const generatePdfFromEndpoint = async () => {
  try {
    setIsLoading(true);
    
    const protocolo = dataRegistro?.protocolo;  // Utilizando o protocolo já consultado
    if (!protocolo) {
      console.error('Protocolo não encontrado.');
      setIsLoading(false);
      return;
    }

    const response = await axios.get(`/api/register/protocolos-registro/exigencia-pdf`, {
      params: { protocolo },
      responseType: 'blob',
    });

    if (response.status !== 200) {
      throw new Error('Falha na geração do PDF');
    }

    const fileURL = URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
    const pdfWindow = window.open();
    pdfWindow.location.href = fileURL;
  } catch (error) {
    console.error('Error fetching PDF from endpoint:', error);
  } finally {
    setIsLoading(false);
  }
};
