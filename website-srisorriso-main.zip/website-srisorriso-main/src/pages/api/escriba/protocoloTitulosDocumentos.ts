// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import https from 'https'
import type { NextApiRequest, NextApiResponse } from 'next'

const httpsAgent = new https.Agent({
  rejectUnauthorized: false
})

async function getAccessToken() {
  const url =
    'https://apievolution.escriba.com.br/oauth/token?username=publico&grant_type=password&tenant=46&password=publico&='
  const key = 'Basic RUlub3ZhLXB1YmxpYzoxNTY3NjI5YjY3Y2U0OTA4YTk1ODRmNTcxYjYzOWExZA=='

  return fetch(url, {
    method: 'post',
    headers: {
      Authorization: key
    },
    //@ts-ignore
    agent: httpsAgent
  })
    .then(response => response.json())
    .then(json => json.access_token)
    .catch(error => console.log('error', error))
}

export default async function protocoloTitulosDocumentos(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const protocolo = req.query.protocolo

  const key = await getAccessToken()
  const access_token = 'bearer ' + key
  const url = 'https://apievolution.escriba.com.br/e-websystems-router/v1/consultar/?'
  const uri = 'uri=/v1/document/titulos-documentos/protocolo'

  let fullUrl = url + uri + '&protocolo=' + protocolo

  return fetch(fullUrl, {
    method: 'get',
    headers: {
      Authorization: access_token
    },
    //@ts-ignore
    agent: httpsAgent
  })
    .then((response) => response.json())
    .then(json => res.send(json))
    .catch((error) => console.error(error))
}
