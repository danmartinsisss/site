// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from "next";
import { initializeApp } from "firebase/app";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { firebaseConfig } from "../../../service/firebaseConfig.json";

const app = initializeApp(firebaseConfig);

export default function handleGetAuth(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const email = req.query.email?.toString();
  const password = req.query.password?.toString();

  const auth = getAuth();
  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      // Signed in
      const user = userCredential.user;
      res.status(200).send(user);
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      res
        .status(403)
        .send({ errorCode: errorCode, errorMessage: errorMessage });
    });
}
