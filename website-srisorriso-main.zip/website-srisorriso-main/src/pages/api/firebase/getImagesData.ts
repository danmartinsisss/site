import type { NextApiRequest, NextApiResponse } from "next";
import admin from "firebase-admin";

const serviceAccount = require("../../../service/website-srisorriso-02d532cdd967.json");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

export default function handleGetImagesData(
  req: NextApiRequest,
  res: NextApiResponse
) {
  async function getImagesData() {
    let allDocs = [];
    const db = admin.firestore();

    const data = await db.collection("images").get();

    data.forEach((doc) => {
      allDocs.push({ id: doc.id, data: doc.data() });
    });

    res.send(allDocs);
  }

  getImagesData();
}
