import type { NextApiRequest, NextApiResponse } from "next";
import admin from "firebase-admin";

const serviceAccount = require("../../../service/website-srisorriso-02d532cdd967.json");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

export default function handleDeleteImage(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const { id } = req.query;

  async function deleteImage() {
    const db = admin.firestore();

    const result = await db
      .collection("images")
      .doc(id as string)
      .delete();

    res.send(result);
  }

  deleteImage();
}
