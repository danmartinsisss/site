import type { NextApiRequest, NextApiResponse } from "next";
import admin from "firebase-admin";

const serviceAccount = require("../../../service/website-srisorriso-02d532cdd967.json");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

export default function handleSetImageData(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const data = req.query.image;

  async function setImageData() {
    const db = admin.firestore();

    const colRef = db.collection("images");

    await colRef
      .add({ imageData: data })
      .then((response) => {
        console.log("Image Data saved successfully");
        res.send(response);
      })
      .catch((error) => {
        console.log("Error saveing image data");
        res.send(error);
      });
  }

  setImageData();
}
