import type { NextApiRequest, NextApiResponse } from "next";
import admin from "firebase-admin";

const serviceAccount = require("../../../service/website-srisorriso-02d532cdd967.json");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

export default function handleSetCurrentNotice(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const title = req.query.title;
  const text = req.query.text;
  const isActivated = req.query.isActivated;

  async function setCurrentNotice() {
    const db = admin.firestore();

    const docRef = db.collection("notices").doc("currentNotice");

    await docRef
      .set({
        title: title,
        text: text,
        isActivated: isActivated,
      })
      .then((response) => {
        console.log("Document created successfully");
        res.send(response);
      })
      .catch((error) => {
        console.log("Error creating document");
        res.send(error);
      });
  }

  setCurrentNotice();
}
