import type { NextApiRequest, NextApiResponse } from "next";
import admin from "firebase-admin";

const serviceAccount = require("../../../service/website-srisorriso-02d532cdd967.json");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

export default function handleGetCurrentNotice(
  req: NextApiRequest,
  res: NextApiResponse
) {
  async function getCurrentNotice() {
    const db = admin.firestore();

    const data = await db.collection("notices").doc("currentNotice").get();

    res.status(200).send(data.data());
  }

  getCurrentNotice();
}
