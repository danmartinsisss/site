import type { NextApiRequest, NextApiResponse } from "next";
import admin from "firebase-admin";

const serviceAccount = require("../../../service/website-srisorriso-02d532cdd967.json");

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

export default function handleSetCurrentNotice(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const title = req.query.title;
  const text = req.query.text;

  async function setModels() {
    const db = admin.firestore();

    const colRef = db.collection("models");

    await colRef
      .add({
        title: title,
        text: text,
      })
      .then((response) => {
        console.log("Model created successfully");
        res.send(response);
      })
      .catch((error) => {
        console.log("Error creating model");
        res.send(error);
      });
  }

  setModels();
}
