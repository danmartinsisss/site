// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import fs from 'fs/promises'
import type { NextApiRequest, NextApiResponse } from 'next'
import path from 'path'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  async function listFiles(directory: string) {
    const files = await fs.readdir(directory)
    return files
  }

  const publicPath = path.resolve('./public')

  const riPath = path.join(publicPath, 'files', 'requerimentos', 'ri')
  const rtdPath = path.join(publicPath, 'files', 'requerimentos', 'rtd')

  const ri = await listFiles(riPath)
  const rtd = await listFiles(rtdPath)

  res.status(200).json({ ri, rtd })
}
