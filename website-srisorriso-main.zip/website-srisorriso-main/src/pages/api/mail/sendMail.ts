// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'
const nodemailer = require('nodemailer')

const user = process.env.MAIL_USR
const pass = process.env.MAIL_PWD

export default function handlerSendMail(req: NextApiRequest, res: NextApiResponse) {
  const data = req.query
  const { name, phone, email, message } = data

  const transporter = nodemailer.createTransport({
    host: 'email-ssl.com.br',
    port: 465,
    secure: true,
    auth: { user, pass }
  })

  transporter
    .sendMail({
      from: 'atendimento@srisorriso.com.br',
      to: 'atendimento@srisorriso.com.br',
      replyTo: email,
      subject: 'Contato via site',
      html: `
              <h2>Contato enviado via formulário do site:</h2>
              <br />
              <h2 style="margin: 0;">Dados do usuário</h2>
              <hr style="width: 200px; margin-left: 0; border-top: 3px solid #bbb;" />
              <div style="border-radius: 5px; background-color: #f2f2f2; padding: 20px;">
                <label for="name">Nome:</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  disabled
                  value="${name}"
                  style="width: 100%;
                  padding: 12px 10px;
                  margin: 8px 0;
                  display: inline-block;
                  border: 1px solid #ccc;
                  border-radius: 4px;
                  box-sizing: border-box;
                  color: #000;
                  font-weight: bold;
                  "
                />
                <label for="email">E-mail:</label>
                <input
                  type="text"
                  id="email"
                  name="email"
                  disabled
                  value="${email}"
                  style="width: 100%;
                  padding: 12px 10px;
                  margin: 8px 0;
                  display: inline-block;
                  border: 1px solid #ccc;
                  border-radius: 4px;
                  box-sizing: border-box;
                  color: #000;
                  font-weight: bold;"
                />
                <label for="phone">Telefone:</label>
                <input
                  type="text"
                  id="phone"
                  name="phone"
                  disabled
                  value="${phone}"
                  style="width: 100%;
                  padding: 12px 10px;
                  margin: 8px 0;
                  display: inline-block;
                  border: 1px solid #ccc;
                  border-radius: 4px;
                  box-sizing: border-box;
                  color: #000;
                  font-weight: bold;"
                />
              </div>
              <br />
              <h2 style="margin: 0;">Interação</h2>
              <hr style="width: 200px; margin-left: 0; border-top: 3px solid #bbb;" />
              <div style="border-radius: 5px; background-color: #f2f2f2; padding: 20px;">
                <label for="message">Mensagem:</label>
                <textarea id="message" name="message" disabled
                style="width: 100%;
                padding: 6px 0 0 10px;
                margin: 8px 0;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
                color: #000;
                font-weight: bold;
                height: 150px;
                ">${message}</textarea>
              </div>
          `
    })
    .then((info: any) => {
      res.status(200).json(info)
    })
    .catch((error: any) => {
      res.status(500).json(error)
    })
}
