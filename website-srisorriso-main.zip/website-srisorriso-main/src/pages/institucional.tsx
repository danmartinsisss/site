import React from "react";
import {
  Container,
  Divider,
  Heading,
  ListItem,
  Text,
  UnorderedList,
} from "@chakra-ui/react";
import { Layout } from "../components/Layout";

const Institucional = () => {
  return (
    <Layout>
      <Container
        maxW="container.lg"
        bgColor="white"
        boxShadow="lg"
        rounded={6}
        mt={6}
        mb={16}
        p={4}
      >
        <Heading fontWeight="thin" textAlign="center" mb={4} color="GrayText">
          INSTITUCIONAL
        </Heading>
        <Divider />
        <Heading size="md" my={4}>
          Conheça o Registro de Imóveis e de Títulos e Documentos de Sorriso
        </Heading>
        <Text css={{ textIndent: "30px" }} textAlign="justify">
          O Serviço de Registro de Imóveis e Títulos e Documentos da Comarca de
          Sorriso - MT, foi instalado no dia 20 de setembro de 1995.
        </Text>
        <Heading size="md" my={4}>
          Sobre o Registrador
        </Heading>
        <Text as="em" fontWeight="semibold">
          Haroldo Canavarros Serra
        </Text>
        <UnorderedList spacing={3} my={4}>
          <ListItem>
            Bacharel em Direito pela Universidade Federal de Mato Grosso.
          </ListItem>
          <ListItem>
            Associado ao Instituto de Registro Imobilário do Brasil - IRIB,
            desde 1981.{" "}
          </ListItem>
          <ListItem>
            Membro do Conselho Fiscal do IRIB&nbsp; na administração Ítalo Conti
            Júnior.{" "}
          </ListItem>
          <ListItem>
            Membro do Conselho de Ética do IRIB na administração&nbsp; Dimas
            Souto Pedrosa.{" "}
          </ListItem>
          <ListItem>
            Membro do Conselho Deliberativo do IRIB na administração Francisco
            José Rezende dos Santos.
          </ListItem>
          <ListItem>
            Membro do Conselho Deliberativo do IRIB na administração Sérgio
            Jacomino.
          </ListItem>
          <ListItem>
            Tabelião substituto de Notas e Protestos,&nbsp; Oficial substituto
            de Registro de Imóveis, Títulos e Documentos e Pessoas Jurídicas da
            Comarca de Rosário Oeste - MT,&nbsp; de julho/1978 à março/1981.{" "}
          </ListItem>
          <ListItem>
            Tabelião de Notas e&nbsp; Protestos, Oficial de Registro de Imóveis,
            Títulos e Documentos e Pessoas Jurídicas do mesmo serviço de
            março/1981 à dezembro/1983.{" "}
          </ListItem>
          <ListItem>
            Nomeado em caráter efetivo por ato governamental publicado no Diário
            Oficial do Estado em 12.12.1983, nos termos do art. 42, V da
            Constituição Estadual c/c o art. 208 da Constituição Federal, com a
            redação dada pela&nbsp; Emenda Constitucional nº 22 de 29.06.1982.{" "}
          </ListItem>
          <ListItem>
            Registrador de Imóveis e de Títulos e Documentos da Comarca de
            Sorriso, a partir de 20.09.1995, por opção decorrente de
            desmembramento de serventia, nos termos do art. 29 da Lei 8.935 de
            18.11.1994.{" "}
          </ListItem>
        </UnorderedList>
      </Container>
    </Layout>
  );
};

export default Institucional;
