import React from "react";
import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Box,
  Container,
  Divider,
  Heading,
  Text,
} from "@chakra-ui/react";
import { Layout } from "../../components/Layout";

export default function DuvidasRi() {
  return (
    <Layout>
      <Container
        maxW="container.lg"
        bgColor="white"
        boxShadow="lg"
        rounded={6}
        mt={6}
        mb={16}
        p={4}
      >
        <Heading fontWeight="thin" textAlign="center" mb={4} color="GrayText">
          PERGUNTAS E RESPOSTAS
        </Heading>
        <Text fontWeight="light" textAlign="center" mb={4} color="GrayText">
          REGISTRO DE IMÓVEIS
        </Text>
        <Divider />
        <Accordion textAlign="justify">
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Qual o Horário de Funcionamento dos Cartórios?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Atualmente no Estado de Mato Grosso as Serventias Notariais e
              Registrais devem ter horário de atendimento ao público de 08
              (oito) horas diárias, preferencialmente no horário das{" "}
              <u>09h00 às 17h00</u>. <br />
              <br />
              Em face das peculiaridades locais de cada cidade, o horário de
              atendimento ao público poderá ser ajustado com autorização do
              juiz, desde que o expediente ao público dure 08 horas diárias e
              respeite os horários de início e encerramento anteriormente
              citados. <br />
              <br />
              O expediente é de segundas às sextas-feiras. Os pontos
              facultativos declarados pelo Poder Judiciário não se estendem as
              Serventias Notariais e Registrais. <br />
              <br />A exceção aos horários e aos dias de expediente externo é do
              Registro Civil das Pessoas Naturais, que deve funcionar 24 horas e
              em todos os dias do ano pelo sistema de plantão.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é Registro e o que é Averbação?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              O termo registro consiste do ato principal do Registro de Imóveis,
              pelo qual os direitos reais são adquiridos, constituídos ou
              transferidos.
              <br />
              <br />A averbação, por sua vez, é acessória em relação ao
              registro, e consiste em ato a ser praticado pelo oficial
              registrador, para consignar fatos supervenientes ao registro.
              Destina-se, pois, a elucidar, modificar ou restringir direitos,
              querem relação ao imóvel, quem em relação ao titular do direito
              real.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é matrícula?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              A matrícula constitui-se do núcleo do registro imobiliário, e
              consiste, grosso modo, numa certidão de nascimento do imóvel, a
              partir do qual serão efetivados registros ou averbações. A
              matrícula é como se fosse um &quotRG&quot do Imóvel, onde se anota
              tudo em relação a ele como quem é o proprietário, se este imóvel
              foi dado em garantia de algum empréstimo, se ele está
              indisponível, penhorado em razão de disputa judicial etc.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é Certidão?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              É a reprodução textual e autêntica de escrito original, ou
              assento, extraída de livro de registro, por oficial público.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é Certidão de Inteiro Teor?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Certidão em inteiro teor , integral ou verbum ad verbum (palavra
              por palavra ) é um documento extraído de um livro de registro que
              reproduz todas as palavras nele contidas. <br />
              <br />A certidão será a reprodução fiel da matrícula do imóvel, em
              inteiro teor, onde constam todos os dados referentes ao imóvel,
              tais como: localização, lote e quadra, nome do proprietário atual,
              datas dos registros e averbações, referência aos documentos
              utilizados para a realização dos registros e averbações, etc.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é Certidão de Ônus?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Ao solicitar a certidão de matrícula com ônus e ações você
              receberá a cópia da matrícula do imóvel, em inteiro teor, onde
              também será certificada a existência ou não de ônus e ações.{" "}
              <br />
              <br />
              As certidões de ônus e ações expedidas pelo Oficial de Registro de
              Imóveis atestam a existência ou não de ônus reais (ex.: hipoteca,
              usufruto, alienação fiduciária, etc.), cláusulas (ex.:
              impenhorabilidade, incomunicabilidade, etc.) ou gravames (ex.:
              penhoras, restrições administrativas, ausência de quitação, etc.)
              constituídos sobre determinado imóvel e, também, a existência ou
              não de registros de citações relativas a ações judiciais reais
              (ex.: usucapião, hipotecária, etc.) ou ações pessoais
              reipersecutórias (ex.: ação pauliana – fraude contra credores).
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é Certidão Quinzenária ou Vintenária?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Consiste na certificação da cadeia dominial, feita pelo
              registrador de imóveis, para o acompanhamento da sequência
              cronológica e legitimidade de toda as transmissões de propriedade,
              ocorridas sobre um mesmo imóvel, a partir do atual proprietário
              até chegar aos últimos 15 (quinze) ou 20 (vinte) anos
              ininterruptos.
              <br />
              <br />
              Chama-se quinzenária porque equivale ao prazo de usucapião
              ordinária previsto no Código Civil de 2002.
              <br />
              <br />
              Chama-se vintenária porque equivale ao prazo de usucapião
              ordinária previsto no Código Civil de 1916.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é cadeia dominial ou certidão de filiação de domínio?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              É o levantamento feito junto ao Cartório de Registro de Imóveis,
              para o acompanhamento da sequência cronológica e legitimidade de
              toda as transmissões de propriedade, ocorridas sobre um mesmo
              imóvel, a partir do atual proprietário até chegar a origem da
              titulação.
              <br />
              <br />
              Geralmente este levantamento abrange mais de um Cartório de
              Registro de Imóveis.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Por que Registrar a Escritura do Imóvel?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Pela legislação brasileira, para se adquirir a propriedade de um
              imóvel, é preciso que o título translativo (escritura pública,
              título definitivo, instrumento particular, formal de partilha,
              carta de arrematação, etc) seja registrado no Registro de Imóveis
              competente.
              <br />
              <br />
              Neste sentido, o §1° do Art 1.245 do Código Civil dispõe que,
              enquanto não se registrar o título translativo, o alienante
              continua a ser havido como dono do Imóvel. Isto significa que se
              não houver o registro em nome do adquirente, a propriedade fica no
              registro imobiliário em nome do vendedor ou transmitente,
              respondendo, inclusive, por dívidas dele, podendo ser penhorado e
              até arrematado judicialmente sem que o comprador fique sabendo.
              Além disso, um transmitente (vendedor p.ex.), sabendo que o
              adquirente não registrou o imóvel em seu nome, pode até,
              fraudulentamente, vendê-lo de novo para um terceiro.
              <br />
              <br />
              E ainda, se este terceiro, com boa-fé, registrar o seu título em
              primeiro lugar, ele será legalmente considerado proprietário,
              restando ao adquirente displicente reclamar do transmitente
              ludibríoso, tão somente perdas e danos.
              <br />
              Como regra, o ordenamento jurídico brasileiro condiciona a
              transmissão de direitos reais relativos à propriedade e a
              constituição de direitos reais de garantia ao registro dos atos e
              negócios perante o Registro de Imóveis.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Onde devo fazer a Escritura Pública?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Não há uma imposição de onde se deve fazer a escritura. As pessoas
              podem sempre procurar o seu tabelião de confiança. Este direito ao
              usuário está garantido no artigo 8º da Lei Federal nº 8.935/94,
              Lei dos Notários e Registradores. <br />
              <br />
              Entretanto a atuação dos notários é vinculada a uma circunscrição,
              devendo se abster de praticar atos fora desse limite por previsão
              do artigo 9º da Lei 8935/94. Desta forma, é proibido ao notário ir
              até outro município para lavrar atos. Mas nada impede que os
              interessados procurem e se dirijam ao Tabelião que melhor lhes
              aprouver, inclusive em outro município. Esta situação ocorre com
              mais frequência por uma questão de praticidade.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Qual o Cartório de Registro de Imóveis Competente?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              O ofício de registro de imóveis competente para registrar a
              escritura será sempre aquele da circunscrição onde o imóvel está
              situado. Esta previsão se justifica para concentrar todas as
              informações de titularidade, ônus, e demais gravames sobre o
              imóvel em um único repositório público.
              <br />
              <br />
              Neste caso, a escolha do Registro de Imóveis, não decorre da
              vontade dos contratantes.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Por que o cálculo não é exato na hora da entrada do título
                  para registro?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              O cálculo realizado na entrada é em caráter prévio ou provisório,
              somente após a análise minuciosa do título é que se verificará
              quais serão os atos (registros e/ou averbações) que serão
              praticados, podendo haver acréscimos ou diminuições no valor
              previamente calculado.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Existe alguma taxa de urgência?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Não. Os serviços são atendidos na rigorosa ordem de protocolo, não
              sendo devido qualquer acréscimo, além dos valores que constam na
              tabela de emolumentos.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Quais são os documentos que necessitam ter a firma
                  reconhecida?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Via de regra, todos os instrumentos particulares que ingressam no
              registro devem trazer as firmas reconhecidas, consoante prevê o
              art. 221, da Lei nº 6.015/73, excetuando-se aqueles em que lei
              especial, dispensar, como é o caso dos contratos oriundos do
              Sistema Financeiro da Habitação, aos quais a lei confere força de
              escritura pública.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Que imposto é o ITBI? E em que hipóteses ele é devido?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              O imposto sobre a transmissão de bens imóveis e de direitos a eles
              relativos (ITBI ) é um imposto de competência municipal, ou seja,
              somente os municípios têm competência para instituí-lo (Art.156,
              II, da Constituição Federal ).
              <br />
              <br />
              O ITBI tem como fato gerador a transmissão, &quotinter vivos&quot,
              a qualquer título, de propriedade ou domínio útil de bens imóveis;
              quando há a transmissão a qualquer título de direitos reais sobre
              imóveis, exceto os direitos reais de garantia; ou quando há a
              cessão de direitos relativos às transmissões acima mencionadas.
              <br />
              <br />
              No Município de Sorriso - MT a alíquota deste imposto é 2% sobre o
              valor do imóvel, que é avaliado e recolhido pelo setor de
              tributação da Prefeitura Municipal.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Que imposto é o ITCD?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              O Imposto sobre Transmissão Causa Mortis e Doação de Quaisquer
              Bens ou Direitos (ITCD) é um tributo que incide sobre a doação ou
              sobre a transmissão hereditária ou testamentária de bens móveis,
              inclusive semoventes, títulos e créditos, e direitos a eles
              relativos ou bens imóveis situados em território do Estado.
            </AccordionPanel>
          </AccordionItem>
        </Accordion>
      </Container>
    </Layout>
  );
}
