import React from "react";
import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Box,
  Container,
  Divider,
  Heading,
  Text,
} from "@chakra-ui/react";
import { Layout } from "../../components/Layout";

export default function DuvidasRtd() {
  return (
    <Layout>
      <Container
        maxW="container.lg"
        bgColor="white"
        boxShadow="lg"
        rounded={6}
        mt={6}
        mb={16}
        p={4}
      >
        <Heading fontWeight="thin" textAlign="center" mb={4} color="GrayText">
          PERGUNTAS E RESPOSTAS
        </Heading>
        <Text fontWeight="light" textAlign="center" mb={4} color="GrayText">
          REGISTRO DE TIULOS E DOCUMENTOS
        </Text>
        <Divider />
        <Accordion textAlign="justify">
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Por que registrar no Registro de Títulos e Documentos?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              O registro de títulos e documentos funciona como um seguro para os
              documentos, protegendo-os contra roubo, incêndio, enchentes ou
              extravios. Se o documento estiver registrado, a qualquer tempo é
              possível solicitar uma certidão que terá o mesmo valor do
              original.
              <br />
              <br />O registro em títulos e documentos comprova a existência, ou
              conteúdo, data e assinatura do documento.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é preciso para registrar em títulos e documentos?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Deve ser apresentado o documento original, ou seja, contratos,
              instrumentos, declarações, traduções, imagens, atas, cartas,
              enfim, todo e qualquer documento desde que seja original.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  Em qual Comarca devo fazer o registro?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              O documento, em regra, deve ser registrado no domicílio das
              pessoas que dele façam parte e, quando residirem em comarcas
              diversas, o registro será feito em todas elas.
              <br />
              <br />
              Se o documento se refere a pessoa jurídica, o endereço a ser
              considerado para fins de registro é o da sua sede.
              <br />
              <br />
              Excepcionalmente a lei especifica que regula o documento poderá
              trazer previsão diversa.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que é registro para fins de conservação?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              Se o apresentante desejar, alguns documentos podem ser registrados
              somente para conservação e, neste caso, não geram efeitos perante
              terceiros. Para o registro para fins de conservação, basta a
              apresentação do documento original acompanhado de requerimento
              solicitando esta modalidade de registro, cujo modelo é fornecido
              pelas próprias Serventias de Registro.
            </AccordionPanel>
          </AccordionItem>
          <AccordionItem>
            <h2>
              <AccordionButton
                _expanded={{
                  fontWeight: "semibold",
                }}
              >
                <Box flex="1" textAlign="left">
                  O que consiste a notificação extrajudicial?
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4}>
              E um ato pelo qual o oficial do Registro de Títulos e Documentos
              dá conhecimento de uma carta ou documento a uma pessoa de forma
              legal e formal.
              <br />
              <br />
              O cartório registra e faz a entrega do documento à pessoa, no
              endereço informado pelo interessado, notificação esta feita
              pessoalmente ou por intermédio de um escrevente com fé pública.
              <br />
              <br />
              O objetivo da notificação é que a pessoa, uma vez notificada, não
              possa mais alegar que desconheça o conteúdo do documento.
              <br />
              <br />
              Depois de entregue a notificação ao notificado, isto é
              certificado, e nessa certidão são informadas e descritas todas as
              circunstâncias da entrega do documento ou se o destinatário não
              foi localizado das ocorrências havidas e das tentativas feitas.
            </AccordionPanel>
          </AccordionItem>
        </Accordion>
      </Container>
    </Layout>
  );
}
