export const linksUteis = [
  {
    href: 'http://www.stf.jus.br/',
    image: '/links/images/logo-stf.png',
    alt: 'STF'
  },
  {
    href: 'http://www.stj.jus.br/',
    image: '/links/images/logo-stj.png',
    alt: 'STJ'
  },
  {
    href: 'http://www.cnj.jus.br/',
    image: '/links/images/logo-cnj.png',
    alt: 'CNJ'
  },
  {
    href: 'http://www.tjmt.jus.br/',
    image: '/links/images/logo-tjmt.png',
    alt: 'TJMT'
  },
  {
    href: 'http://www.irib.org.br/',
    image: '/links/images/logo-irib.png',
    alt: 'IRIB'
  },
  {
    href: 'http://www.irtdpjbrasil.com.br/',
    image: '/links/images/logo-irtdpj.jpg',
    alt: 'IRTDPJ'
  },
  {
    href: 'http://www.anoreg.org.br/',
    image: '/links/images/logo-anoreg-br.png',
    alt: 'ANOREG/BR'
  },
  {
    href: 'http://www.anoregmt.org.br/',
    image: '/links/images/logo-anoreg-mt.webp',
    alt: 'ANOREG/MT'
  },
  {
    href: 'http://www.receita.fazenda.gov.br/',
    image: '/links/images/logo-rfb.png',
    alt: 'Receita Federal'
  },
  {
    href: 'https://www.gov.br/trabalho-e-previdencia/pt-br/assuntos/previdencia-social',
    image: '/links/images/logo-previdencia.png',
    alt: 'Previdência Social'
  },
  {
    href: 'http://www.incra.gov.br/',
    image: '/links/images/logo-incra.png',
    alt: 'INCRA'
  },
  {
    href: 'http://www.ibama.gov.br/',
    image: '/links/images/logo-ibama.png',
    alt: 'IBAMA'
  },
  {
    href: 'http://www.mt.gov.br/',
    image: '/links/images/logo-gov-mt.jpg',
    alt: 'Governo de Mato Grosso'
  },
  {
    href: 'http://www.sorriso.mt.gov.br/',
    image: '/links/images/logo-pref-sorriso.png',
    alt: 'Município de Sorriso'
  },
  {
    href: 'http://www.presidencia.gov.br/legislacao/',
    image: '/links/images/legislacao.jpg',
    alt: 'Lesgislação'
  },
  {
    href: 'https://www.cnj.jus.br/wp-content/uploads/2023/08/codigo-nacional-de-normas-da-corregedoria-nacional-de-justica-v6-23-08-2023.pdf',
    image: '/links/images/logo-cnj-normas.png',
    alt: 'Código Nacional de Normas da CNJ'
  },
  {
    href: 'https://corregedoria-mc.tjmt.jus.br/corregedoria-arquivos-prod/cms/Cod_Nor_CGJ_Foro_Extra_Prov_42_2020_At_Prov_10_2022_CGJ_e0f4f35c26.pdf',
    image: '',
    alt: 'Código de Normas da CGJ'
  },
  {
    href: '/files/Provimento n. 38-2023-CGJ Republicado.pdf',
    image: '',
    alt: 'Tabela de Emolumentos de Mato Grosso'
  },
  {
    href: 'https://sistema.cei-anoregmt.com.br/',
    image: '/images/ceimt.png',
    alt: 'CEI/ANOREG'
  }
]
